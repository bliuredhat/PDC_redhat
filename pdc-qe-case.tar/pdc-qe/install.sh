#!/bin/bash

#  File name: install.sh
#  Date:      2013/10/14
#  Author:    xgao@redhat.com
#  Update date:    2014/07/17


# install the required packages
#packages='python python-kerberos krb5-workstation \
#    python-setuptools python-devel uuid-devel \
#    pkgconfig libtool gcc-c++'
#yum groupinstall 'Development Tools'
packages="python python-kerberos krb5-workstation python-setuptools \
    perl-SOAP-Lite perl-LWP-Authen-Negotiate perl-LWP-Protocol-https \
    python-devel uuid-devel pkgconfig libtool gcc-c++ openssl"
yum groupinstall -y 'Development Tools'
yum install -y $packages

# config tcms.conf
echo "config tcms.conf ..."
robotfile="/etc/tcms.conf"
cp tcms.conf $robotfile

# config krb5
echo "config krb5 ..."
krbfile="/etc/krb5.conf"
echo "copy krb5.conf to /etc"
cp krb5.conf $krbfile

# install nitrate.py
echo "install nitrate ..."
pythonpath=`python -c "from distutils.sysconfig import get_python_lib;\
                        print get_python_lib()"`
nitratefile="nitrate.py"
nitrate=${pythonpath}/${nitratefile}
if [ -f "$nitrate" ]
then
    echo "nitrate already installed"
else
    cp $nitratefile $pythonpath
fi

# create worker shop for slave
mkdir /home/automation

# install robotx, and other python packs
easy_install pip
easy_install -U PyCrypto
pip install pyzmq
pip install robotx
pip uninstall -y fabric paramiko
pip install paramiko==1.10 fabric
# cp RedHat cert file
echo "starting install cert..."
certPath='/etc/pki/ca-trust/source/anchors/'
certFile="newca.crt"
cp $certFile $certPath
openssl x509 -noout -fingerprint -in $certPath/$certFile 
openssl x509 -in $certPath/$certFile -out $certPath/newca.pem -outform PEM
update-ca-trust
echo "cert install successfully"

# install robotx
easy_install robotx
easy_install kobo

echo "Done"
