#!/bin/bash

#  File name: install.sh
#  Date:      2013/10/14
#  Author:    xgao@redhat.com


# install the required packages
packages='python python-kerberos krb5-clients python-setuptools'
apt-get install -y $packages

# config tcms.conf
echo "config tcms.conf ..."
robotfile="/etc/tcms.conf"
cp tcms.conf $robotfile

# config krb5
echo "config krb5 ..."
krbfile="/etc/krb5.conf"
echo "copy krb5.conf to /etc"
cp krb5.conf $krbfile

# install nitrate.py
echo "install nitrate ..."
pythonpath=`python -c "from distutils.sysconfig import get_python_lib;\
                        print get_python_lib()"`
nitratefile="nitrate.py"
nitrate=${pythonpath}/${nitratefile}
if [ -f "$nitrate" ]
then
    echo "nitrate already installed"
else
    cp $nitratefile $pythonpath
fi

# install robotx
easy_install robotx

echo "Done"
