"""
Sets variables for tests.

Environment variable PDC_QE_SERVER can override default server name for
testing.

Server name is also passed to pdc and pdc_client (parameter "--server=...").

Default server name is "qa" (other values are "dt", "dt2", "local").
"""

import os

qa = os.getenv('PDC_QE_SERVER', 'qa')

# default protocol
protocol = 'https://'

# default DB server settings
dbname = 'pdc'
user = 'pdc'
passwd = 'pdc'
port = 5432

# Acceptance test
if qa == 'qa':
    Server = 'pdc.host.qe.eng.pek2.redhat.com'
# Daily test
elif qa == 'dt':
    Server = 'pdc-dt.host.qe.eng.pek2.redhat.com'
elif qa == 'dt2':
    Server = 'pdc-02.host.qe.eng.pek2.redhat.com'
    #qa = 'dt'
# Local development test
elif qa == 'local':
    protocol = 'http://'
    Server = 'localhost:8000'
else:
    raise Exception('Unknown test server name: "%s"' % qa)

HomePageURL = protocol + Server
host = Server
