#!/usr/bin/env python

# This document is to build keywords for PDC automation test.
#
# You can get more information from the followed link:
# https://docs.engineering.redhat.com/display/HTD/PDC+automation+keywords
# If This link have any problem,please update the content, more clear
# and more helpful.
#


import string
import random
import re
import kerberos
import pprint
from robot.libraries.BuiltIn import BuiltIn
import sys
import os
import copy
import json
import requests
import psycopg2
import subprocess
from requests_kerberos import HTTPKerberosAuth

_VALIDATION_METHODS = {
    'list': lambda e: isinstance(e, list),
    'str': lambda e: True,
    'int': lambda e: isinstance(e, int),
    'bool': lambda e: isinstance(e, bool),
    'dict': lambda e: isinstance(e, dict),
    'nullable': lambda e: True
}

def _generate_random_string():
    '''generate 5~10 characters for a string,
    for example:
        str_para= _generate_random_string()
    : the value of str_para is \'afg134\'. the value contains
    letters and digits.
    '''
    str_num = random.randint(5, 10)
    str_list = string.letters + string.digits
    maxi = len(str_list) - 1
    return ''.join(str_list[random.randint(0, maxi)] for _ in xrange(str_num))

def _generate_special_string():
    ''' generate a 8 characters for a string.
    The string just contains 'abcdefABCDEF0123456789',
    and doesn't contain others letters.
    '''
    str_num = 8
    str_list = 'abcdefABCDEF0123456789'
    maxi = len(str_list) - 1
    return ''.join(str_list[random.randint(0, maxi)] for _ in xrange(str_num))


class StringContaining(object):
    '''
    Represents all string containing selected substring.

    Examples:

    >>> StringContaining('23') == '12345'
    true

    >>> StringContaining('56') == '12345'
    false
    '''
    def __init__(self, substring):
        self.substring = substring

    def __eq__(self, string):
        return self.substring in string

    def __str__(self):
        return '*{}*'.format(self.substring)


class PDCLIB(object):
    def __init__(self, path, dbname, user, passwd, host, port, qa_para):
        self.dbname = dbname
        self.user = user
        self.passwd = passwd
        # Host name without port number.
        self.host = re.sub(r':\d+$', '', host)
        self.port = port
        self.results = ''
        self.result_flag = 0
        self.server = path
        self.method = ''
        self.url = ''
        self.params = ''
        self.data = ''
        self.json = None
        self.cookies = None
        self.files = None
        self.auth = None
        self.timeout = None
        self.allow_redirects = None
        self.proxies = None
        self.verify = None
        self.stream = None
        self.cert = None
        self.command = ''
        self.results_changeset = []
        self.results_change = []
        self.tmp_value = None
        self.domain = self.server + '/rest_api/v1/auth//token/obtain/'
        self.token_refresh_url = self.server + '/rest_api/v1/auth/token/refresh/'
        print 'PDC **curl** server is: ', self.server
        self.the_builtin = BuiltIn().get_library_instance('BuiltIn')
        self.header = '-H \"Content-Type: application/json\" '

        # Use token for communication if protocol is https.
        if self.domain.startswith('https://'):
            #flag_token = os.popen('curl -s -k --negotiate -u : -H "Content-Type: application/json" '+self.domain )
            flag_token = os.popen('curl -s -k --negotiate -u : -H "Accept: application/json" '+self.domain )
            flag_token = flag_token.read()
            try:
                flag_token = eval(flag_token)
                self.token = flag_token['token']
            except SyntaxError:
                self.the_builtin.fatal_error('\n\n===You need to do "kinit"====\n')
            self.header += ' -H \"Authorization:  Token  '+self.token+'\"'

        self.old_id_from_changeset = []
        self.new_id_from_changeset = []
        self.results_sql = []

        self.num_req = None
        self.num_sql = None
        self.last_changeset_id = 0

        self.pdc_client_data = None
        self.pdc_client = qa_para
        self.pdc_client_last_changeset_id = None
        self.pdc_client_method = ''
        self.pdc_client_server = ''

        self.compose_id = None

    def run_with_para_sql(self, table=None):
        print "input table is:%s" % table
        conn = psycopg2.connect(database=self.dbname, user=self.user, password=self.passwd, host=self.host, port=self.port)
        cur = conn.cursor()
        query = 'select count(*) from' + ' ' + table
        print "input:%s" % query
        cur.execute(query)
        results = cur.fetchall()
        conn.close()
        print "results**:%s" % results
        if results[0]:
            print "pass"
            print "the SQL results is :%s\n" % results
        else:
            print "can't find the results in table under the given condition\n"

    def run_id_with_para_sql(self, table=None):
        print "input table is:%s" % table
        conn = psycopg2.connect(database=self.dbname, user=self.user, password=self.passwd, host=self.host, port=self.port)
        cur = conn.cursor()
        query = 'select compose_id from' + ' ' + table
        print "input:%s" % query
        cur.execute(query)
        results = cur.fetchall()
        conn.close()

        if results[0]:
            print "pass"
            print "the SQL results is :%s\n" % results
        else:
            print "can't find the results in table under the given condition\n"

    def execute_db_queries(self, *queries):
        conn = psycopg2.connect(database=self.dbname, user=self.user, password=self.passwd, host=self.host, port=self.port)
        with conn:
            with conn.cursor() as cur:
                for query in queries:
                    print "SQL query: %s" % query
                    cur.execute(query)
                    print "row count: %s" % (cur.rowcount,)
        conn.close()

    def verify_count_between_db_and_api(self, table=None):
        """
        """
        print "input table is:%s" % table
        conn = psycopg2.connect(database=self.dbname, user=self.user, password=self.passwd, host=self.host, port=self.port)
        cur = conn.cursor()
        query = 'select count(*) from' + ' ' + table
        print "input:%s" % query
        cur.execute(query)
        results_sql = cur.fetchall()
        self.num_sql = int(results_sql[0][0])
        print "db total number is=%s" % self.num_sql
        print "api total number is :%s" % self.num_req
        conn.close()
        if self.num_sql != self.num_req:
            print "the count of databse and api are not same"
            raise
        else:
            print "the count of databse and api are same"

    def client_verify_changeset_values(self, *para):
        '''
        This keyword is verified the tracks of the update
        action whether happened.
        The format of para is:
        para={\'new\':string/dict,\'old\':string/dict}
        using in the auto-scripts:
        |  client_verify_changeset_values  |  para  |

        '''
        command = ' pdc_client -s {} -r changesets/{}/ -x get'.format(
            self.pdc_client, self.pdc_client_last_changeset_id)
        print "command is %s" % command
        res = os.popen(command)
        result = res.read()
        result = json.loads(result)
        actual_results_old = []
        actual_results_new = []
        if self.pdc_client_last_changeset_id:
            for temp_changes in result['changes']:
                if temp_changes['resource'] == 'internal':
                    actual_results_new.append(temp_changes['new_value'])
                    actual_results_old.append(temp_changes['old_value'])
                else:
                    if temp_changes['new_value'] == 'null':
                        actual_results_new.append(temp_changes['new_value'])
                    else:
                        actual_results_new.append(json.loads(temp_changes['new_value']))
                    if temp_changes['old_value'] == 'null':
                        actual_results_old.append(temp_changes['old_value'])
                    else:
                        actual_results_old.append(json.loads(temp_changes['old_value']))
        print "changesets new_value is %s,changesets old_value is %s" % (actual_results_new,actual_results_old)
        for sub_para in para:
            sub_para = self.the_builtin.evaluate(sub_para)
            if sub_para:
                if 'new' in sub_para.keys():
                    self._common_verify_changes(sub_para['new'], actual_results_new)

                if 'old' in sub_para.keys():
                    self._common_verify_changes(sub_para['old'], actual_results_old)

    def _common_verify_changes(self, test_para, expect_para):
        if isinstance(test_para, str):
            if test_para in expect_para:
                pass
            else:
                print ' FAIL '.center(84, '='), '\n'
                print "%s is not in changelog %s" % (test_para, expect_para)
                self.the_builtin.run_keyword_and_continue_on_failure("fail")
        if isinstance(test_para, dict):
            for sub_key, sub_value in test_para.items():
                if not self._verify_key_value(expect_para, sub_key, sub_value):
                    print ' FAIL '.center(84, '='), '\n' * 2
                    self._print_value_fail_info(sub_key, sub_value)

                    self.the_builtin.run_keyword_and_continue_on_failure("fail")
                else:
                    continue
        if isinstance(test_para, list):
            for x in test_para:
                self._common_verify_changes(x, expect_para)

    def pdc_client_current_list(self):
        '''
        Returns the last changeset ID and stores it internally for
        other keywords to verify changesets.
        '''
        command = 'pdc_client -s {} -r changesets/?page_size=1&fields=id'.format(self.pdc_client)
        self.pdc_client_last_changeset_id = self._changeset_list_current(command)
        return self.pdc_client_last_changeset_id

    def client_verify_changeset_targets(self, *para):
        '''
        This keyword verify the table name which have been updated
        by the latest action.
        para is string/list format.
        |  client_verify_changeset_targets   |   para   |
        '''
        command = 'pdc_client -s {} -r changesets/{}/ -x get'.format(
            self.pdc_client, self.pdc_client_last_changeset_id)
        print "command is %s" % command
        print "input para type is", type(para)
        print "changeset para value:", para
        res = os.popen(command)
        result_temp = json.loads(res.read())
        if self.pdc_client_last_changeset_id == 0:
            if 'null' not in para:
                print 'fail'.center(50, '=')
                print "%s is not in changeset." % para
                raise
        else:
            resource_list = []
            for temp_target in result_temp['changes']:
                resource_list.append(temp_target['resource'])
            print "***resource_list***:", resource_list
            for para_i in para:
                if para_i in resource_list:
                    print ' PASS'.center(50, '=')
                    continue
                else:
                    print "%s is not in %s" % (para, resource_list)
                    print ' FAIL'.center(50, '=')
                    raise

    def client_run_command(self, para):
        '''
        Keyword:run_pdc_client_para
        para :{'methd':str,'resource':str,'data':dict}
        'method' is in ['get','post',...],
        'resource' is set to API's name
        'data' is parameter in command
        this keyword use pdc_client command,and run with method/
        resource/para as client set.
        '''
        pdc_command = ' pdc_client -s ' + str(self.pdc_client) + ' -r '
        print para
        print "type", type(para)
        if para:
            para = eval(str(para))
        else:
            pass
        if 'method' in para.keys():
            pdc_method = str(para['method'])
            self.pdc_client_method = pdc_method
            if pdc_method in ['get', 'post', 'delete', 'patch', 'put']:
                pass
            else:
                print "please make sure input right method"
                raise
        else:
            print "please input corect method"
            raise
        if 'resource' in para.keys():
            pdc_server = str(para['resource'])
            self.pdc_client_server = pdc_server
        else:
            print "please input resource"
            raise
        if 'data' in para.keys():
            pdc_data = json.dumps(para['data'])
        else:
            pdc_data = None
            pass
        pdc_command += pdc_server
        if pdc_data:
            if pdc_method == 'get':
                pdc_command = pdc_command+'  -d  ' + repr(pdc_data)
            else:
                pdc_command = pdc_command + '  -x  ' + pdc_method + '  -d  ' + repr(pdc_data)
        elif pdc_method != 'get':
            pdc_command = pdc_command + '  -x  ' + pdc_method
        print "**pdc_command**:%s" % pdc_command
        res = os.popen(pdc_command)
        if res:
            flag_read = res.read()
            try:
                result = json.loads(flag_read)
            except ValueError, e:
                print ' error info'.center(84, '='), '\n'
                print flag_read
                raise
            print "pdc_results value1:%s" % result
            if pdc_method == 'GET' and _VALIDATION_METHODS['list'](result):
                self.num_req = len(result)
                self.results = result
            elif _VALIDATION_METHODS['dict'](result) and 'count' in result.keys():
                self.num_req = result['count']
                self.results = result['results']
                print "actual result", self.results
            elif _VALIDATION_METHODS['dict'](result) and 'count' not in result.keys():
                self.num_req = 1
                self.results = result
            else:
                self.num_req = 0
                self.results = result
        self.pdc_client_current_list()
        print "pdc_count is:%s" % self.num_req
        return self.num_req

    def client_verify_exceptions(self, **kargs):
        '''
        Keyword:run_and_verify_pdc_client_negative_parameters.
        The function is: when input error parameter,make sure the
        result whether as expected results
        kargs:{\'parameters\':dict,\'expected\':str/dict}
        The value of \'parameters\' input \'method\'/\'data\'/\'resource';
        and the \'method\'/\'resource\' can run with the default that
        para in client_run_command
        '''
        for key, value in kargs.items():
            expected_results = eval(value)['expected']
            parameters = eval(value)['parameters']
            print "para****:%s" % parameters
            if _VALIDATION_METHODS['dict'](parameters):
                if 'method' in parameters.keys():
                    self.pdc_client_method = parameters['method']
                else:
                    pass
                pdc_method = self.pdc_client_method
                if 'data' in parameters.keys():
                    pdc_data = json.dumps(parameters['data'])
                else:
                    pdc_data = None
                if 'resource' in parameters.keys():
                    self.pdc_client_server = parameters['resource']
                else:
                    pass
                pdc_server = self.pdc_client_server
            print '**para is: %s,** expected_result is: %s' % (parameters, expected_results)
        pdc_command = ' pdc_client -s ' + str(self.pdc_client) + '  -r  '
        pdc_command = pdc_command + pdc_server
        if pdc_method in ['get', 'post', 'delete', 'patch', 'put']:
                pass
        else:
            print "please make sure input right method"
            raise
        if pdc_data:
            if pdc_method == 'get':
                pdc_command = pdc_command + '  -d  ' + repr(pdc_data)
            else:
                pdc_command = pdc_command + ' -x ' + pdc_method + ' -d ' + repr(pdc_data)

        print "**pdc_command**:%s" % pdc_command
        proc = subprocess.Popen(
            pdc_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout_content, result_read = proc.communicate()

        print "stderr:", stdout_content, type(stdout_content)
        self.the_builtin.should_be_equal(
            stdout_content, "", msg="Stdout of pdc_client should be empty on error.")

        exit_code = proc.returncode
        self.the_builtin.should_not_be_equal(
            exit_code, 0, msg="Exit code of pdc_client should be non-zero on error.")
        self.the_builtin.should_be_true(
            exit_code >= 0,
            msg="A negative exit code -N indicates that the child was terminated by signal N.")

        print "result value:", result_read, type(result_read)
        try:
            actual_list = re.split(' ', result_read, 1)  #get the dict
            print "list ", actual_list
            actual_results = json.loads(actual_list[1])
        except ValueError:
            actual_results = json.loads(result_read)
            pass
        print "actual_results type", type(actual_results)
        print "expected_results type", type(expected_results)
        if expected_results != actual_results:
            self.result_flag += 1
            print ' Expected Results '.center(50, '=')
            pp = pprint.PrettyPrinter()
            pp.pprint(expected_results)
            print ' FAIL INFO '.center(50, '=')
            if expected_results != actual_results:
                print '\nFault String is wrong!!!!'
            if actual_results:
                print ' Actual Results '.center(50, '=')
                pp = pprint.PrettyPrinter()
                pp.pprint(actual_results)
        else:
            print '\nPASS'
        print ' End '.center(84, '='), '\n' * 2
        if self.result_flag:
            self.the_builtin.run_keyword_and_continue_on_failure("fail")

    def _changeset_list_current(self, command):
        res = os.popen(command)
        result = json.loads(res.read())
        if result['count'] > 0:
            last_changeset_id = result['results'][0]['id']
        else:
            last_changeset_id = 0
        print "current_id", last_changeset_id
        return last_changeset_id

    def changeset_list_current(self):
        '''
        Returns the last changeset ID and stores it internally for
        other keywords to verify changesets.
        '''
        command = 'curl -s -k {} -G {}/rest_api/v1/changesets/?page_size=1&fields=id'.format(
            self.header, self.server)
        self.last_changeset_id = self._changeset_list_current(command)
        return self.last_changeset_id

    def _verify_change(self, resource, old_value, new_value, get_change):
        """
        Verifies whether resource, old_value and new_value matches latest
        changeset.

        :param get_change: Called with value of changes field in the latest \
                           changeset and returns single change.
        """
        command = 'curl -s -k {} -G {}/rest_api/v1/changesets/?page_size=1'.format(
            self.header, self.server)
        res = os.popen(command)
        result = json.loads(res.read())
        changeset = result['results'][0]
        print('Last changeset: {}'.format(changeset))
        change = get_change(changeset['changes'])

        self.the_builtin.run_keyword_and_continue_on_failure(
            "Should Be Equal", change.get('resource'), resource)

        for field, expected_value in (('old_value', old_value), ('new_value', new_value)):
            actual_value = json.loads(change.get(field))
            print('  Actual {}: {}'.format(field, actual_value))
            print('Expected {}: {}'.format(field, expected_value))
            if isinstance(actual_value, dict) and isinstance(expected_value, dict):
                self.the_builtin.run_keyword_and_continue_on_failure(
                    "Dictionaries Should Be Equal", actual_value, expected_value)
            else:
                self.the_builtin.run_keyword_and_continue_on_failure(
                    "Should Be Equal", actual_value, expected_value)

    def verify_change(self, resource, old_value, new_value):
        """
        Verify that give resource, old_value and new_value is single change in
        latest changeset.
        """
        def get_change(changes):
            if len(changes) != 1:
                raise Exception('Expected single change in latest changeset.')
            return changes[0]
        self._verify_change(resource, old_value, new_value, get_change)

    def verify_change_with_index(self, index, resource, old_value, new_value):
        """
        Verify resource, old_value and new_value from change at given index
        from latest changeset.
        """
        def get_change(changes):
            return changes[int(index)]
        self._verify_change(resource, old_value, new_value, get_change)

    def verify_change_with_resource_id(self, resource_id, resource, old_value, new_value):
        """
        Verify resource, old_value and new_value from change with given
        resource_id from latest changeset.
        """
        def get_change(changes):
            for change in changes:
                if str(resource_id) == change['resource_id']:
                    return change
            raise Exception(
                    'Change with resource_id={} not found in latest changeset'.format(resource_id))
        self._verify_change(resource, old_value, new_value, get_change)

    def curl_verify_changeset_values(self, *para):
        '''
        This keyword is to verify the action whether create a track or
        tracks.
        the para :{'new':str/dict,'old':str/dict}
        The tracks will create when run command with post/patch/delete method.
        '''
        command = 'curl -s -k {} -X GET {}/rest_api/v1/changesets/{}/'.format(
            self.header, self.server, self.last_changeset_id)
        print "command is %s" % command
        res = os.popen(command)
        result = res.read()
        result = json.loads(result)
        actual_results_old = []
        actual_results_new = []
        if self.last_changeset_id:
            for temp_changes in result['changes']:
                if temp_changes['resource'] == 'internal':
                    actual_results_new.append(temp_changes['new_value'])
                    actual_results_old.append(temp_changes['old_value'])
                else:
                    if temp_changes['new_value'] == 'null':
                        actual_results_new.append(temp_changes['new_value'])
                    else:
                        actual_results_new.append(json.loads(temp_changes['new_value']))
                    if temp_changes['old_value'] == 'null':
                        actual_results_old.append(temp_changes['old_value'])
                    else:
                        actual_results_old.append(json.loads(temp_changes['old_value']))
        print "changesets new_value is ", actual_results_new, "changesets old_value is ",actual_results_old
        for sub_para in para:
            sub_para = self.the_builtin.evaluate(sub_para)
            if sub_para:
                if 'new' in sub_para.keys():
                    self._common_verify_changes(sub_para['new'], actual_results_new)
                if 'old' in sub_para.keys():
                    self._common_verify_changes(sub_para['old'], actual_results_old)

    def curl_verify_changeset_targets(self, *para):
        '''
        This keyword is to verify the table name When run with the
        post/patch/delete method.
        And if exist,will pass.
        '''
        command = 'curl -s -k {} -X GET {}/rest_api/v1/changesets/{}/'.format(
            self.header, self.server, self.last_changeset_id)
        print "***command~***:", command
        print "***resource value***:", para
        res = os.popen(command)
        result_temp = json.loads(res.read())
        if self.last_changeset_id == 0:
            if 'null' not in para:
                print 'fail'.center(50, '=')
                print "%s is not in changeset." % para
                raise
        else:
            resource_list = []
            for temp_target in result_temp['changes']:
                resource_list.append(temp_target['resource'])
            print "***resource_list***:%s" % resource_list
            for para_i in para:
                if para_i in resource_list:
                    print ' PASS'.center(50, '=')
                    continue
                else:
                    print "%s is not in %s" % (para, resource_list)
                    print ' FAIL'.center(50, '=')
                    raise
    
    def pdc_obtain_token(self):
        "Get new token "
        f_token = os.popen('curl -s -k --negotiate -u : -H "Content-Type: application/json" ' + self.domain )
        self.token = f_token.read()
        print self.token

    def pdc_refresh_token(self):
        "Refresh your token"
        f_token = os.popen('curl -s -k --negotiate -u : -H "Content-Type: application/json" ' + self.token_refresh_url )
        self.token = f_token.read()
        print self.token

    def set_curl_method(self, method):
        "Set method for the curl command"
        method_name = str(eval(method))
        if method_name in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']:
            self.method = method_name
            print self.method
        else:
            print "&&", method_name, type(method_name)
            print "method_name is not in ['GET','POST','PUT','DELETE']"

    def set_curl_urls(self, url_data):
        "Set url for the curl command"
        if _VALIDATION_METHODS['str'](url_data):
            self.url = str(eval(url_data))
            print self.url
        else:
            print 'url is str stype,please make sure'

    def curl_run_command(self, parameters=None):
        """string for xmlrpc_execute"""
        if parameters:
            parameters = eval(parameters)
            print type(parameters)
            if _VALIDATION_METHODS['dict'](parameters):
                if 'params' in parameters.keys():
                    self.params = parameters['params']
                else:
                    self.params = None
                if 'data' in parameters.keys():
                    self.data = json.dumps(parameters['data'])
                else:
                    self.data = None
            else:
                print 'params is str or dict,please make sure params'
                raise
        else:
            self.data = None
            self.params = None
            print "no parameters"
        if self.method == 'GET':
            self.command = 'curl -s -k ' + self.header + '  -G  ' + self.url
        else:
            self.command = 'curl -s -k ' + self.header + '  -X  ' + self.method + ' ' + self.url
        if self.params or self.data:
            if self.params:
                if self.method == 'GET':
                    print "self.para:%s" % self.params
                    para_temp = self.change_dict_to_str(self.params)
                    self.command = self.command + '   ' + para_temp
                else:
                    self.command = self.command + '  -d  ' + repr(self.params)
            else:
                pass
            if self.data:
                self.command = self.command + '  -d  ' + repr(self.data)
            else:
                pass
        tpp = pprint.PrettyPrinter()
        print 'curl~command:%s' % self.command
        result = os.popen(self.command + '  -s')
        #result = os.popen(self.command)
        res = result.read()
        #print 'Test'.center(50, '=')
        #tpp.pprint(res)
        if res:
            results = json.loads(res)
            #tpp.pprint(self.method == 'GET')
            #tpp.pprint(_VALIDATION_METHODS['dict'](results))
            if self.method == 'GET' and _VALIDATION_METHODS['list'](results):
            #if self.method == 'GET' and _VALIDATION_METHODS['dict'](results):
                self.num_req = len(results)
                self.results = results
            elif _VALIDATION_METHODS['dict'](results) and 'count' in results.keys():
                self.num_req = results['count']
                self.results = results['results']
            else:
                self.results = results
                self.num_req = None
                print "$$$$%s" % self.results
        else:
            self.results = "there is no result return"
        self.changeset_list_current()
        print 'PDC Execution Results'.center(50, '=')
        pp = pprint.PrettyPrinter()
        pp.pprint(self.results)

    def random_update_compose_command(self):
        "update a document with random value"
        status = ["untested", "passed", "failed"]
        result_temp = self.results
        rrt_result = self.get_value_from_result('rtt_tested_architectures')
        print " *rr* ", rrt_result
        if isinstance(rrt_result, dict):
            result = {}
            for key, value in rrt_result.items():
                temp = {}
                if isinstance(value, dict):
                    for key_2 in value.keys():
                        temp[key_2] = random.choice(status)
                result[key] = temp
            print result
            return result
        elif isinstance(rrt_result, list):
            result = []
            for para in rrt_result:
                re_temp = {}
                for key, value in para.items():
                    temp = {}
                    if isinstance(value, dict):
                        for key_2 in value.keys():
                            temp[key_2] = random.choice(status)
                re_temp[key] = temp
                result.append(re_temp)
            return result
        else:
            print "******can't get params for result******"
            raise

    def get_result(self):
        return self.results

    def get_results(self, expected_results_count):
        if not isinstance(self.results, list):
            raise Exception("Results must be list")
        if len(self.results) != int(expected_results_count):
            raise Exception(
                "Unexpected number of results, expected {}, got {}".format(
                    expected_results_count, len(self.results)))
        return self.results

    def get_id_from_result(self):
        if isinstance(self.results, list):
            results = []
            for component in self.results:
                results.append(component['id'])
            return results
        elif isinstance(self.results, dict):
            return self.results['id']

    def get_value_from_result(self, testkey):
        '''Get the value from result
        |   ${value}=  | get_value_from_result  |  key  |

        '''
        print "testkey value is %s,type is  %s" % (testkey, type(testkey))
        if isinstance(self.results, list):
            result_list = []
            for temp_value in self.results:
                status = self._get_value_from_dict(temp_value, testkey)
                if status['flag']:
                    result_list.append(status['testvalue'])
                else:
                    pass
            if result_list and len(result_list) == 1:
                return result_list[0]
            elif len(result_list) > 1:
                return result_list
            else:
                print "can't find the value of %s" % testkey
                raise
        elif isinstance(self.results, dict):
            status = self._get_value_from_dict(self.results, testkey)
            if not status['flag']:
                self.the_builtin.run_keyword_and_continue_on_failure("fail")
            else:
                return status['testvalue']
        else:
            print "%s can't be find in %s" % (testkey, self.results)
            raise

    def get_value_by_tree(self, para):
        para = eval(para)
        if isinstance(para, dict) or isinstance(para, list):
            return self.get_value_by_tree_bottom(self.results, para)
        else:
            print "The format of para is not correct. Type of para is:"
            print type(para)

    def get_value_by_tree_bottom(self, results, para):
        #--------if result is single operation result------
        if isinstance(results, dict):
            if isinstance(para, dict):
                dict_key1 = para.keys()[0]
                dict_value1 = para.values()[0]
                try:
                    value = results[dict_key1][dict_value1]
                    return value
                except KeyError:
                    print "%s or %s can't exist in results" % (dict_key1, dict_value1)
                    pass
            if isinstance(para, list):
                try:
                    value = results[para[0]]
                    return value
                except KeyError:
                    print "%s is not key in results" % para[0]
                    pass
        #------results of bulk operation-----------------
        elif isinstance(results, list):
            value_list = []
            for result in results:
                #-----recursion-----
                value_list.append(self.get_value_by_tree_bottom(result, para))
            #import ipdb; ipdb.set_trace()
            return value_list
        #-----format of result is not correct-------
        else:
            print "The format of results is not correct. Type of results is:"
            print type(results)
            return None

    #for get value using list para'["103478","contact","id"]' -- using in bulk update testing
    def get_value_by_list(self, para):
        para = eval(para)
        if isinstance(para, list):
            results_ = self.results
            for k in para:
                results_ = results_[k]
            return results_
        else:
            print "The format of para is not correct. Type of para is:"
            print type(para)

#*******************************************
    def _get_value_from_dict(self, result, testkey):
        """docstring"""
        status = {'flag': 0, 'testvalue': ''}
        if isinstance(result, dict):
            for key, value in result.items():
                if testkey == key:
                    status['flag'] += 1
                    status['testvalue'] = result[testkey]
                    return status
                elif isinstance(value, dict) or isinstance(value, list):
                    status = self._get_value_from_dict(value, testkey)
                    if status['flag']:
                        break
                else:
                    continue
        elif isinstance(result, list):
            for thevalue in result:
                if isinstance(thevalue, dict) or isinstance(thevalue, list):
                    status = self._get_value_from_dict(thevalue, testkey)
                    if status['flag']:
                        break
                else:
                    continue
        else:
            pass
        return status

    def curl_client_verify_result_includes(self, *args, **kargs):
        """for verify the xmlrpc result"""
        for arg in args:
            print '>>>>>arg=%s' % type(arg)
            print 'arg value:', args
            print 'self.results type=%s' % type(self.results)
            if not _VALIDATION_METHODS['int'](arg):
                arg = self.the_builtin.evaluate(arg)
            else:
                pass
            if not self._verify_single(self.results, arg):
                self._print_key_fail_info(arg)
            else:
                continue
        print "+++kargs+++===", kargs, type(kargs)
        for key, value in kargs.items():
            if 'para' in key:
                if value and not _VALIDATION_METHODS['int'](value):
                    value = self.the_builtin.evaluate(value)
                    print "value", value, type(value)
                else:
                    pass
                if _VALIDATION_METHODS['dict'](value):
                    for sub_key, sub_value in value.items():
                        if not self._verify_key_value(self.results, sub_key, sub_value):
                            self._print_value_fail_info(sub_key, sub_value)
                        else:
                            continue
                else:
                    pass
            else:
                if not _VALIDATION_METHODS['int'](value):
                    value = self.the_builtin.evaluate(value)
                else:
                    pass
                print 'step2-'
                if not self._verify_key_value(self.results, key, value):
                    self._print_value_fail_info(key, value)
                else:
                    continue
        if self.result_flag:
            self.the_builtin.run_keyword_and_continue_on_failure("fail")

    def curl_verify_exceptions(self, **kargs):
        """for running batch of xmlrpc negative testing"""
        for key, value in kargs.items():
            expected_results = eval(value)['expected']
            parameters = eval(value)['parameters']
            print "para****:%s" % parameters
            if _VALIDATION_METHODS['dict'](parameters):
                if 'params' in parameters.keys():
                    self.params = parameters['params']
                else:
                    self.params = None
                if 'data' in parameters.keys():
                    self.data = json.dumps(parameters['data'])
                else:
                    self.data = None
                if 'url' in parameters.keys():
                    self.url = parameters['url']
            print '**para is: %s,** expected_result is: %s' % (parameters, expected_results)
            if self.method == 'GET':
                self.command = 'curl -s -k  ' + self.header + '  -G  ' + self.url
            else:
                self.command = 'curl -s -k  ' + self.header + '  -X  ' + self.method + ' ' + self.url
            if self.params or self.data:
                if self.params:
                    if self.method == 'GET':
                        print "self.para:%s" % self.params
                        para_temp = self.change_dict_to_str(self.params)
                        self.command = self.command + '  ' + para_temp
                    else:
                        self.command = self.command + '  -d  ' + repr(self.params)
                else:
                    pass
                if self.data:
                    self.command = self.command + '  -d  ' + repr(self.data)
                else:
                    pass
            else:
                self.command += '  -d  \'\'  '
            print 'curl~command:%s' % self.command
            result = os.popen(self.command)
            actual_results = json.loads(result.read())
            if expected_results != actual_results:
                self.result_flag += 1
                print ' Expected Results '.center(50, '=')
                pp = pprint.PrettyPrinter()
                pp.pprint(expected_results)
                print ' FAIL INFO '.center(50, '=')
                if expected_results != actual_results:
                    print '\nFault String is wrong!!!!'
                if actual_results:
                    print ' Actual Results '.center(50, '=')
                    pp = pprint.PrettyPrinter()
                    pp.pprint(actual_results)
            else:
                print '\nPASS'
            print ' End '.center(84, '='), '\n' * 2
        if self.result_flag:
            self.the_builtin.run_keyword_and_continue_on_failure("fail")

    def _print_key_fail_info(self, keyword):
        """print fail info"""
        self.result_flag += 1
        print 'FAIL INFO'.center(80, '=')
        print '\nthe key/value "%s" is not in the result!!!!\n' % keyword

    def _print_value_fail_info(self, key, value):
        """print fail info"""
        self.result_flag += 1
        print 'FAIL INFO'.center(80, '=')
        print '\nthe KEY VALUE "{%s: %s}" is wrong\n' % (key, str(value))
        print 'Expected result is: ', self.tmp_value

    def _verify_single(self, result, single):
        """docs..."""
        status = 0
        if isinstance(result, dict):
            for key, value in result.items():
                if single == None and value == None:
                    status += 1
                    break
                if single == key or single == value:
                    status += 1
                    break
                elif isinstance(value, dict):
                    if value == single:
                        status += 1
                        break
                    status = self._verify_single(value, single)
                    if status:
                        break
                elif isinstance(value, list):
                    if value == single:
                        status += 1
                        break
                    status = self._verify_single(value, single)
                    if status:
                        break
                else:
                    continue
        elif isinstance(result, list):
            for thevalue in result:
                if single == thevalue:
                    status += 1
                    break
                elif isinstance(thevalue, dict):
                    status = self._verify_single(thevalue, single)
                    if status:
                        break
                elif isinstance(thevalue, list):
                    for listvalue in value:
                        status = self._verify_single(listvalue, single)
                        if status:
                            break
                else:
                    continue
        else:
            pass
        return status

    def _verify_key_value(self, result, testkey, testvalue):
        """docs..
        Verify the result whether contains the testkey and the corresponding
        value.
        """
        status = 0
        if isinstance(result, dict):
            for key, value in result.items():
                if not testvalue:
                    if key == testkey:
                        status += 1
                        break
                    else:
                        continue
                else:
                    if {key: value} == {testkey: testvalue}:
                        status += 1
                        break
                    elif key == testkey and value != testvalue:
                        self.tmp_value = value
                    elif isinstance(value, dict) or isinstance(value, list):
                        status = self._verify_key_value(value, testkey, testvalue)
                        if status:
                            break
                    else:
                        continue
        elif isinstance(result, list):
            for thevalue in result:
                if isinstance(thevalue, dict) or isinstance(thevalue, list):
                    status = self._verify_key_value(thevalue, testkey, testvalue)
                    if status:
                        break
                else:
                    continue
        return status
#********************* change dict to str *****************
    def change_dict_to_str(self, para):
        para_dict = eval(str(para))
        para_str = ''
        if not para_dict:
            return para_str
        else:
            pass
        for key, value in para_dict.items():
            para_str = para_str + '  -d  ' + '\"' + str(key) + '=' + str(value) + '\"'
            print "para for GET:%s" % para_str

        return para_str

    def get_string_from_right(self, str_para, str_maker='/', num_para=2):
        print str_para, type(str_para)
        if isinstance(str_para, list):
            val_temp = []
            for i_temp in str_para:
                if i_temp:
                    val_temp.append(eval(i_temp.split(str_maker)[-num_para]))
                else:
                    pass
            return val_temp
        elif str_para:
            print str_para,
            str_para = str(str_para)
            print type(str_para)
            return eval(str_para.split(str_maker)[-num_para])
        else:
            print "please input str"
            raise
    
    def generate_random_string_list(self, count_para=None):
        if count_para == None:
            return _generate_random_string()
        elif count_para:
            count_para = eval(count_para)
            value_list = []
            for i in xrange(count_para):
                value_list.append(_generate_random_string())
            return value_list
        else:
            pass

    def generate_special_string(self, count_para=None):
        "Generate a random string"
        if count_para == None:
            return _generate_special_string()
        elif count_para:
            count_para = eval(count_para)
            value_list = []
            for i in xrange(count_para):
                value_list.append(_generate_special_string())
            return value_list
        else:
            pass

    def get_value_from_dict(self, dict_para=None, key_para=None):
        print dict_para
        if dict_para and key_para:
            value_status = self._get_value_from_dict(dict_para, key_para)
            if value_status['flag']:
                return value_status['testvalue']
            else:
                print "can't find the value in %s" % dict_para
                raise
        else:
            print "please input dict_para or key_para"
            raise

    def get_key_from_dict(self, dict_arg=None):
        print dict_arg
        if isinstance(dict_arg, dict):
            return dict_arg.keys()
        else:
            print "%s is not dict format." % dict_arg
            raise

    def new_client_run_command(self, para):
        '''
        Keyword:run_pdc_client_para
        para :{'methd':str,'resource':str,'data':dict,'id':list}
        'method' is in ['list','info',...],
        'resource' is set to API's name
        'data' is parameter in command
        'id' is id in command
        this keyword use pdc command,and run with method/
        resource/para as client set.
        'check_expect_result' means check with wrong param, /
         and "check_expect_result": "expect_error"
        'sleep_time' sleep for a while when doing the delete/check job
        '''
        pdc_command = ' pdc -s ' + str(self.pdc_client) + ' --json '
        print para
        print "type", type(para)
        if para:
            para = eval(str(para))
        else:
            pass
        if 'method' in para.keys():
            pdc_method = str(para['method'])
            self.pdc_client_method = pdc_method
            if pdc_method in ['list', 'info', 'create', 'update', 'delete', 'clone', 'delete-match']:
                pass
            else:
                print "please make sure input right method"
                raise
        else:
            print "please input corect method"
            raise
        if 'resource' in para.keys():
            pdc_server = str(para['resource'])
            self.pdc_client_server = pdc_server
        else:
            print "please input resource"
            raise
        if 'data' in para.keys():
            pdc_data = json.dumps(para['data'])
        else:
            pdc_data = None
            pass
        if 'id' in para.keys():
            pdc_id = para['id']
        else:
            pdc_id = None
            pass

        pdc_command += pdc_server
        pdc_command = pdc_command + ' ' + pdc_method
        if pdc_id:
            for pdc_key1 in pdc_id:
                pdc_command = pdc_command + ' ' + pdc_key1
        if pdc_data:
            for pdc_key2 in para['data'].keys():
                if isinstance(para['data'][pdc_key2], dict):
                    for pdc_key3 in para['data'][pdc_key2].keys():
                        if isinstance(para['data'][pdc_key2][pdc_key3], list):
                            pdc_command = pdc_command + ' --' + pdc_key3 + ' ' + str(para['data'][pdc_key2][pdc_key3])
                        else:
                            pdc_command = pdc_command + ' --' + pdc_key3 + ' ' + para['data'][pdc_key2][pdc_key3]
                elif isinstance(para['data'][pdc_key2], list):
                    pdc_command = pdc_command + ' --' + pdc_key2 + ' ' + str(para['data'][pdc_key2])
                else:
                    pdc_command = pdc_command + ' --' + pdc_key2 + ' ' + para['data'][pdc_key2]

        print "**pdc_command**:%s" % pdc_command
        if "check_expect_result" in para.keys():
            proc = subprocess.Popen(pdc_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output = proc.stdout.read()
            if para["check_expect_result"] in output:
                return
            raise Exception("Test failed")
        res = os.popen(pdc_command)
        res1 = res.read()
        if res1:
            result = json.loads(res1)
            print "pdc_results value1:%s" % result
            if pdc_method == 'list' and _VALIDATION_METHODS['list'](result):
                self.num_req = len(result)
                self.results = result
            elif _VALIDATION_METHODS['dict'](result) and 'count' in result.keys():
                self.num_req = result['count']
                self.results = result['results']
                print "actual result", self.results
            elif _VALIDATION_METHODS['dict'](result) and 'count' not in result.keys():
                self.num_req = 1
                self.results = result
            else:
                self.num_req = 0
                self.results = result
        self.pdc_client_current_list()
        print "pdc_count is:%s" % self.num_req
        return self.num_req

############# import keywords #################
    def curl_client_import_command(self, parameters=None):
        """string for xmlrpc_execute"""
        if parameters:
            parameters = eval(parameters)
            print "type", type(parameters)
            if _VALIDATION_METHODS['dict'](parameters):
                if 'type' in parameters.keys():
                    if parameters['type'] == 'curl':
                        if 'data' in parameters.keys():
                            self.data = json.dumps(parameters['data'])
                        else:
                            self.data = None

                        if self.method == 'POST':
                            self.command = 'curl -s -k ' + self.header + ' -X ' + self.method + ' ' + self.url
                        if self.data:
                            self.command = self.command + ' -d ' + self.data
                        else:
                            pass
                        print 'curl~command:%s' % self.command
                        result = os.popen(self.command + '  -s')
                        res = result.read()
                        if res:
                            results = json.loads(res)
                            if _VALIDATION_METHODS['dict'](results) and 'count' in results.keys():
                                self.num_req = results['count']
                                self.results = results['results']
                            else:
                                self.results = results
                                self.num_req = None
                                print "$$$$%s" % self.results
                        else:
                            self.results = "there is no result return"
                        self.changeset_list_current()
                        print 'PDC Execution Results'.center(50, '=')
                        pp = pprint.PrettyPrinter()
                        pp.pprint(self.results)

                    elif parameters['type'] == 'client':
                        pdc_command = ' pdc_client -s ' + str(self.pdc_client) + ' -r '
                        if 'method' in parameters.keys():
                            pdc_method = str(parameters['method'])
                            self.pdc_client_method = pdc_method
                            if pdc_method in ['get', 'post', 'delete', 'patch', 'put']:
                                pass
                            else:
                                print "please make sure input right method"
                                raise
                        else:
                            print "please input corect method"
                            raise
                        if 'resource' in parameters.keys():
                            pdc_server = str(parameters['resource'])
                            self.pdc_client_server = pdc_server
                        else:
                            print "please input resource"
                            raise
                        if 'data' in parameters.keys():
                            pdc_data = json.dumps(parameters['data'])
                        else:
                            pdc_data = None
                            pass
                        pdc_command += pdc_server
                        if pdc_data:
                            if pdc_method == 'post':
                                pdc_command = pdc_command + '  -x  ' + pdc_method + '  -d  ' + pdc_data
                        print "**pdc_command**:%s" % pdc_command
                        res = os.popen(pdc_command)
                        if res:
                            flag_read = res.read()
                            try:
                                result = json.loads(flag_read)
                            except ValueError, e:
                                print ' error info'.center(84, '='), '\n'
                                print flag_read
                                raise
                            print "pdc_results value1:%s" % result
                            if _VALIDATION_METHODS['dict'](result) and 'count' in result.keys():
                                self.num_req = result['count']
                                self.results = result['results']
                                print "actual result", self.results
                            elif _VALIDATION_METHODS['dict'](result) and 'count' not in result.keys():
                                self.num_req = 1
                                self.results = result
                            else:
                                self.num_req = 0
                                self.results = result
                        self.pdc_client_current_list()
                        print "pdc_count is:%s" % self.num_req
                        return self.num_req
            else:
                print 'params is str or dict,please make sure params'
                raise
        else:
            self.data = None
            print "no parameters"



#***************************************************************************
if __name__ == '__main__':
    url_server = 'https://pdc-dt.host.qe.eng.pek2.redhat.com/'
    url = "\'https://pdc-dt.host.qe.eng.pek2.redhat.com/rest_api/v1/composes/\'"
    database = "pdc_prod"
    user = "pdc"
    password = "pdc"
    host = 'pdc-dt.host.qe.eng.pek2.redhat.com'
    pdc_client = 'dt'
    port = str(5432)
    method_test = "\'GET\'"
    c_id = []
    total_id = 0
#    para1 = "{'params': {'page_size':100, 'page':1}}"
#    print "***",method_test
#    print "***",url
#    print "***********",para1
    LIB = PDCLIB(url_server, database, user, password, host, port, pdc_client)
    # c_id = LIB.run_id_with_para_sql('compose_compose')
    # print '******', list(c_id)
    LIB.set_curl_method(method_test)
    LIB.set_curl_urls(url)

    # for r in range(1, 5):
    #     para1 = "{'params': {'page_size':100, 'page':" + str(r) + "}}"
    #     print "**", para1
    #     LIB.curl_run_command(para1)
    #     composes_id = LIB.get_value_from_result('compose_id')
    #     total_id = total_id + len(composes_id)
    #     c_id =c_id + composes_id

    # print "******c_id is *******",c_id
    # print "*******", total_id

    with open('/home/xuguo/qe-automation/tests/Pdc/resources/id.txt', 'r') as f:
        for line in f.readlines():
            print(line.strip())

            url = "\'https://pdc-dt.host.qe.eng.pek2.redhat.com/rest_api/v1/compose-rpms/" + str(line.strip()) + "/\'"
            LIB.set_curl_urls(url)
            LIB.curl_run_command()

            if 'detail' in LIB.results:
                print "error %s compose_id" % line.strip()
                raise
