#!/usr/bin/python

import unittest
import beanbag.v2 as beanbag
from beanbag.v2 import GET

class ListRelease(unittest.TestCase):

    def setUp(self):
        # ReleaseTestBase.setUp(self)
        pass

    def tearDown(self):
        pass

    def test_list_release(self):
        """list a release"""
        self.pdc_server = 'pdc.engineering.redhat.com'
        self.pdc_release = 'supp-7.4@rhel-7'
        
        api_client = beanbag.BeanBag("http://%s/rest_api/v1/" % self.pdc_server)
        
        self.release_api = api_client.releases(release_id = self.pdc_release)
        self.release_list = GET(self.release_api)
        print('The release is: %s \n') % self.release_list

        # Validate test result

if __name__ == '__main__':
    unittest.main()
