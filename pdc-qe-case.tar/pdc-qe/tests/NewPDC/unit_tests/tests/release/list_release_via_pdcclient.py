#!/usr/bin/python

import unittest
import subprocess



class ListRelease(unittest.TestCase):

    def setUp(self):
        # ReleaseTestBase.setUp(self)
        pass

    def tearDown(self):
        pass

    def test_list_release(self):
        """list releases"""
        self.cmd = '/usr/bin/pdc_client -s dt -r releases'
        
        print('The releases are: %s \n') % subprocess.check_output(self.cmd,shell=True)

        # Validate test result

if __name__ == '__main__':
    unittest.main()
