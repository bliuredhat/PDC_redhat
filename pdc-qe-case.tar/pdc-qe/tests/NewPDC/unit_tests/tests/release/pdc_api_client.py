#!/usr/bin/python

import beanbag.v2 as beanbag
from beanbag.v2 import GET

class PdcApiClient():

    def __init__(self, server_name):
#        if "https://" in service_url:
#            service_url = service_url.replace("https://", "http://")
        self.server_name = server_name
        self.api_client = beanbag.BeanBag("http://%s/rest_api/v1/" % server_name)

