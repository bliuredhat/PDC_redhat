#!/usr/bin/python

import unittest
import subprocess
import pdb
from PDCLIB import PDCLIB

class CreateOneRelease(unittest.TestCase):

    def setUp(self):
        self.url_server = 'https://pdc.host.qe.eng.pek2.redhat.com/'
        self.url = "\'https://pdc.host.qe.eng.pek2.redhat.com/rest_api/v1/releases/\'"
        self.database = "pdc"
        self.user = "pdc"
        self.password = "pdc"
        self.host = 'pdc.host.qe.eng.pek2.redhat.com'
        self.pdc_client = 'qa'
        self.port = str(5432)

    def tearDown(self):
        pass

    def test_create_one_release(self):
        """create one release"""
        self.method_test = "\'POST\'"
        self.resource = "releases"
        #self.para = {'method':'get','resource':'push-targets'}

        pdcinit = PDCLIB(self.url_server, self.database, self.user, self.password, self.host, self.port, self.pdc_client)
        #self.r_name = _generate_random_string
        #self.r_short = _generate_random_string
        #self.r_version = _generate_random_string(4,chars=[NUMBERS])
        self.r_name = "releasename"
        self.r_short = "releaseshort"
        self.r_version = "1"
        #pdb.set_trace() 
        self.para = {'method':'post','resource':'releases','data':{'name':self.r_name,'short':self.r_short,'version':self.r_version,'product_version':'rhel-7','release_type':'ga','active':'True'}}
        
        #para :{'method':str,'resource':str,'data':dict}
        pdcinit.client_run_command(self.para)
        
        # Validate test result

if __name__ == '__main__':
    unittest.main()
