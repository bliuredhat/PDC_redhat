import unittest
import subprocess
import pdb
import sys
sys.path.append("../../../unit_tests/common/")
from PDCLIB import *  
import PDCLIB as pdclib

class CreateOneRelease(unittest.TestCase):
    """Create one release via pdc_client"""

    def setUp(self):
        self.url_server = 'https://pdc.host.qe.eng.pek2.redhat.com/'
        self.url = "\'https://pdc.host.qe.eng.pek2.redhat.com/rest_api/v1/releases/\'"
        self.database = "pdc"
        self.user = "pdc"
        self.password = "pdc"
        self.host = 'pdc.host.qe.eng.pek2.redhat.com'
        self.pdc_client = 'qa'
        self.port = str(5432)

    def tearDown(self):
        pass

    def test_create_one_release(self):
        """create one release"""
        self.method_test = "\'POST\'"
        self.resource = "releases"
        pdcinit = PDCLIB(self.url_server, self.database, self.user, self.password, self.host, self.port, self.pdc_client)

        self.r_name = pdclib._generate_random_string()
        self.r_short = pdclib._generate_random_string()
        #self.r_name = "releasename"
        #self.r_short = "releaseshort"
        self.r_version = "1"
        #pdb.set_trace() 
        #para :{'method':str,'resource':str,'data':dict}
        self.para = {'method':'post','resource':'releases','data':{'name':self.r_name,'short':self.r_short,'version':self.r_version,'product_version':'rhel-7','release_type':'ga','active':'True'}}
        pdcinit.client_run_command(self.para)
        
        # Validate test result
        self.changeset_target = "release"
        self.changeset_value = {'new':{'name':self.r_name,'short':self.r_short,'version':self.r_version},'old':'null'}
        pdcinit.client_verify_changeset_targets(self.changeset_target)
        pdcinit.client_verify_changeset_values(self.changeset_value)

if __name__ == '__main__':
    unittest.main()
