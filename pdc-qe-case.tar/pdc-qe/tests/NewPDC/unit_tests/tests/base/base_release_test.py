import unittest
from unit_tests.tests.base.base_test import TestBase


class ReleaseTestBase(TestBase):

    def setUp(self):
        TestBase.setUp(self)

