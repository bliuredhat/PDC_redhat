import unittest
from unit_tests.common import test_run_common
from unit_tests.common import test_validator


class TestBase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.server = None
        #self.run = test_run_helper.TestRunHelper(self)
        #self.validator = test_validator.TestValidator(self)
        print "\n==== Test case: %s ====" % self.shortDescription()

