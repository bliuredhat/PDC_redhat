#!/usr/bin/python
import requests
import json
from beanbag import BeanBagException
#import pdc_client
#from pdc_client import PDCClient
import ssl
import beanbag.v2 as beanbag
from beanbag.v2 import GET

#PDC_SERVER = 'pdc-dt.host.qe.eng.pek2.redhat.com'
PDC_SERVER = 'pdc.engineering.redhat.com'
pushtargets_name = 'rhn-live'

myapi = beanbag.BeanBag("http://%s/rest_api/v1/" % PDC_SERVER)

pushtargetsAPI = myapi.pushtargets(name = pushtargets_name)
print('The push target is: %s \n') % pushtargetsAPI
