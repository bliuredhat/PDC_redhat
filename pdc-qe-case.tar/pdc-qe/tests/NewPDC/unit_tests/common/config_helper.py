#config help 
