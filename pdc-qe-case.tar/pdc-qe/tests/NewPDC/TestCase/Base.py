#-*- coding=utf-8 -*-
'''
@summary: The base class for all test case classes.
'''

# ChangeLog:
# Version    Date            Desc                Author
# --------------------------------------------------------

import os
import unittest
from Utils.xmlprase import dataload
import Utils.common_variables as variants
from Utils.PublicMethod import printLog, execSshCmd
from TestRun.TestCenter import load_global_config

class BaseTestCase(unittest.TestCase):
    # @classmethod
    def setUp(self):
        '''
        dict_data = load_global_config()
        self.database = dict_data['globalconf']['database']['value']
        self.user = dict_data['globalconf']['user']['value']
        self.password = dict_data['globalconf']['password']['value'] 
        self.host = dict_data['globalconf']['hostname']['value']
        self.url_server = 'https://' + self.host + '/'
        self.pdc_client = dict_data['globalconf']['pdc_client']['value']
        self.port = dict_data['globalconf']['port']['value']
        '''
        self.database = variants.dbname 
        self.user = variants.user
        self.password = variants.passwd
        self.host = variants.Server
        self.url_server = 'https://' + self.host + '/'
        self.pdc_client = variants.qa
        self.port= variants.port
 
    def initData(self):
        pass

    # @classmethod
    def tearDown(self):
        pass
    
    def setTestResult(self, result='pass', message='No more message.'):
        if result.lower() == 'pass':
            printLog("Test case has been executed successfully, here is the message: %s" % message, 'pass')
            # self.assertTrue(True, "True")
        elif result.lower() == 'fail':
            printLog(message)
            raise self.failureException("Test case execute failed, here is the message: %s" % message)
        else:
            printLog("The test result should be 'pass' or 'fail', your input is not supported.", "error")
            return False
        
    def setResultFalse(self, message):
        return self.setTestResult('fail', message)

if __name__ == "__main__":
    
    unittest.main()
