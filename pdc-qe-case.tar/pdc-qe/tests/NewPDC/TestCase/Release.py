import unittest
import subprocess
import pdb
import sys
from ApiObject.PDCLIB import *  
import ApiObject.PDCLIB as pdclib
from Base import BaseTestCase
from ApiObject.ReleaseApi import ReleaseApi
from Utils.PublicMethod import printLog


class CreateOneRelease(BaseTestCase):
    """Create one release via pdc_client"""

    def setUp(self):
        super(CreateOneRelease, self).setUp()     # Run Base setUp() firstly,super is a class not a function
        # Firstly, initiate Data and instance
        self.url = self.url_server + 'releases/'
        #print ('url is %s' % (self.url))

    def tearDown(self):
        pass

    def test_create_one_release(self):
        """create one release"""
        self.method_test = "\'POST\'"
        self.resource = "releases"
        pdcinit = PDCLIB(self.url_server, self.database, self.user, self.password, self.host, self.port, self.pdc_client)

        self.r_name = pdclib._generate_random_string()
        self.r_short = pdclib._generate_random_string()
        self.r_short = 'short-' + self.r_short
        self.r_version = "1"
        #pdb.set_trace() 
        #para :{'method':str,'resource':str,'data':dict}
        self.para = {'method':'post','resource':'releases','data':{'name':self.r_name,'short':self.r_short,'version':self.r_version,'product_version':'rhel-7','release_type':'ga','active':'True'}}
        pdcinit.client_run_command(self.para)
        
        # Validate test result
        self.changeset_target = "release"
        self.changeset_value = {'new':{'name':self.r_name,'short':self.r_short,'version':self.r_version},'old':'null'}
        pdcinit.client_verify_changeset_targets(self.changeset_target)
        pdcinit.client_verify_changeset_values(self.changeset_value)


if __name__ == '__main__':
    #unittest.main()
    pass
