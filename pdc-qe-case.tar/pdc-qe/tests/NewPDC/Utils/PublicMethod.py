# -*- coding=utf-8 -*-
"""
Public function and method moudle
Class Description:
    None
Funtion Description:
    printLog: Print log
    getCurInfo: Get the name and line number for current excution function
    execSshCmd: Run Shell command on remote Linux host
    catchException: Handle exception
"""

import sys
import os
import paramiko

from datetime import datetime
from traceback import print_exc

from xmlprase import xmlutil

from TestRun.TestCenter import get_log_level
#from TestCase.Base import BaseTestCase


def printLog(log, message_type="mess"):
    global log_level
    '''
    Information type(Case Insensitive):
        Mess: Normal message
        Warn: Warning message
        Error: Error message
        Pass: Test case runs successfully
        Fail: Test case runs failed
        Debug: Debug message
    '''
    log_dict = {
        "mess":  "-MESSAGE-",
        "warn":  "-WARNING-",
        "error": "--ERROR--",
        "pass":  "--PASS---",
        "fail":  "--FAIL---",
        "debug": "--DEBUG--",
    }
    
#     curPath = os.path.abspath(os.path.dirname(__file__))
#     global_config_file = os.path.dirname(curPath) + os.path.sep + "TestRun" + os.path.sep + "GlobleConf.xml"
#     xml = xmlutil()
#     xml.load(global_config_file)
#     try:
#         log_level = int(xml.get_log_level())
#     except ValueError: 
#         print >> sys.stderr, "Only number is supported!"
#         return False
    
    # print log_level
    log_level = get_log_level()
    
    if (log_level == 0 or
            (log_level == 1 and message_type.lower() != "debug") or
            (log_level == 2 and message_type.lower() in ("error", "fail", "warn"))):
        try:
            display_level = log_dict[message_type.lower()]
        except:
            printLog("You can't use this method by %s" % (message_type), "Error")
        else:
            _print_log(log, display_level)
            return True
    elif log_level > 2 or log_level < 0:
        print >> sys.stderr, "Unsupported log level!"
    else:
        return False
        
        
            
def _print_log(log, level):
    now = datetime.now()
    if level in ("--ERROR--", "--FAIL---"):
        print >> sys.stderr, "[%s %s ]: %s" \
                % (str(now.strftime("%Y-%m-%d %H:%M:%S")), level, log)
    else:
        try:
            print "[" + str(now.strftime("%Y-%m-%d %H:%M:%S")) + " " + level + " ]: %s" % (log)
        except:
            printLog("You can't use this method by %s" % (level), "Error")
    


def getCurInfo():
    """Return the frame object for the caller's stack frame."""
    try:
        raise Exception
    except:
        f = sys.exc_info()[2].tb_frame.f_back
    return (f.f_code.co_name, f.f_lineno)


def execSshCmd(ip, cmd, user='root', password='redhat'):
    '''
    @summary: Run Shell command on remote Linux host 
    @param: 
        ip: Remote host you'd like to connect
        user: User name for ssh login, root by default
        password: password for ssh login，redhat by default
        cmd: Command or script you'd like to run can be imported in a list or tuple, command could be run in order.
    @return: 
        Run successfully, will return a result list, e.g.
            ls return  [['anaconda-ks.cfg\n', 'buildInfo\n', 'debuginfo_install', ...]]
            You need search twice if you'd like to get strings from this list
        Will return False if run unsuccessfully
    '''
    output = []
    try:
        ssh = paramiko.SSHClient()  # Inite a ssh instance
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # Set add host public key as "AutoAddPolicy"
        ssh.connect(ip, 22, user, password, timeout=5)
        for m in cmd:
            stdin, stdout, stderr = ssh.exec_command(m)
            output_mess = stdout.readlines() + stderr.readlines()
            printLog("The output of command '%s' is '%s'." % (m, output_mess), 'debug') 
            output.append(output_mess)
        printLog('Run command "%s" on "%s" successfully.' % (cmd, ip), 'debug')
        ssh.close()
        return output
    except:
        e = sys.exc_info()[0]
        printLog('The command on "%s"("%s") is failed! Reason: %s' % (ip, cmd, e), "Error")
        return False
        
def catchException(message=None):
    '''
    @summary: Decorator for exception
    @param: 
        message: information to print
        f: function
    '''
    def _call(f):
        def __call(*args, **kwds):
            try:
                data = f(*args, **kwds)
            except Exception as e:
                printLog(message if message else
                         "There is something wrong in your method(function) %s, here is some messages:" % 
                         f.__name__, 
                         "error")
                print_exc()
                return e.args
            else:
                return data
        return __call
    return _call

def retry(retry_times=3):
    '''
    @summary: Decorator for retry
    @param f: input one function or method you want to retry
    @param retry_times: give the times number you would like to retry, 3 by default
    '''
    def _call(f):
        def __call(*args, **kwarg):
            for i in range(retry_times + 1):  # +1, because the first time retry doesn't count in retry tims.
                if i:
                    printLog(
                        'Retry function: %s, retry times: %d.' % (f.__name__, i),
                        'debug'
                    )
                return_value = f(*args, **kwarg)
                if return_value:
                    break
            else:
                printLog(
                    'Function(Method) %s executed failed after %d times retries.' % 
                    (f.__name__, retry_times), 
                    'error'
                )
            return return_value
        return __call
    return _call

if __name__ == '__main__':
    ExecSshCmd("10.8.241.209", "ls /root/", password='redhat')
    print printLog("end", 'error')

