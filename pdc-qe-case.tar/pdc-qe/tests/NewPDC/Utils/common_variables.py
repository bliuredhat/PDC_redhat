"""
Sets variables for tests.

Environment variable PDC_QE_SERVER can override default server name for
testing.

Server name is also passed to pdc and pdc_client (parameter "--server=...").

Default server name is "qa" (other values are "dt", "dt2", "local").
To avoid hard code user name and password into test cases to run against applications, we use environment vairants on test server:
    PDC_USER
    PDC_PASSWD

"""

import os

global qa
global dbname
global user
global passwd
global port 

# get environment variants
qa = os.getenv('PDC_QE_SERVER', 'qa')
user = os.getenv('PDC_USER')
passwd = os.getenv('PDC_PASSWD')

# default protocol
protocol = 'https://'

# default DB server settings
dbname = 'pdc'
port = 5432

# Acceptance test
if qa == 'qa':
    Server = 'pdc.host.qe.eng.pek2.redhat.com'
# Daily test
elif qa == 'dt':
    Server = 'pdc-dt.host.qe.eng.pek2.redhat.com'
elif qa == 'dt2':
    Server = 'pdc-02.host.qe.eng.pek2.redhat.com'
    #qa = 'dt'
# Local development test
elif qa == 'local':
    protocol = 'http://'
    Server = 'localhost:8000'
else:
    raise Exception('Unknown test server name: "%s"' % qa)

HomePageURL = protocol + Server
host = Server
