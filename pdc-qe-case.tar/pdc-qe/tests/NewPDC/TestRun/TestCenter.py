﻿# -*- coding=utf-8 -*-

"""
Main entrance of automation framework
Description:
    Parse config files and triger some types of testing
Funtion:
    load_tests: Load test cases by global variant test_cases
    initialize: Return tc_list according to the test case configration file
    createTestCase: Return test case suite according to configration filename 
    create_testcase_by_module: Return test case suite by test case module name, e.g. releas
    get_log_level: Get current log_level from file GlobalConf
    load_global_config: Import global configurations from file GlobalConf.xml by dataload
    get_project_dir: Get Absolute Pathname for this project
    get_testcase_dir: Get Absolute Pathname for test cases directory
    get_test_result_path: Get Absolute Pathname to store test results
    executeTest: Trigger Test run
"""

__all__ = []

# ChangeLog:
# Version    Date            Desc                                Author
# ----------------------------------------------------------------------------------------
# V0.1       10/21/2017      Initiation                          meli 
# ----------------------------------------------------------------------------------------

import os
import sys
import re
import time

reload(sys)
sys.setdefaultencoding('utf-8')

def get_project_dir():
    '''
    @summary: Get Absolute Pathname for this project
    '''
    cur_path = os.path.abspath(os.path.dirname(__file__))
    return os.path.dirname(cur_path) + os.path.sep

project_path = get_project_dir()
print "Project path %s is: " % project_path
if get_project_dir() not in sys.path:
    sys.path.append(get_project_dir())

from copy import deepcopy
from unittest import TestSuite
from unittest import TestLoader

from Utils.xmlprase import dataload
from Utils.HTMLTestRunner import HTMLTestRunner
from Utils.xmlprase import xmlutil

# sys.path.append(os.path.dirname((os.path.abspath(os.path.dirname(__file__)))))

tc_list = []  # Parse configurations from xml file
xu = xmlutil()
test_cases = []  # test case for this run
# _log_level = None

def load_tests():
    '''
    @summary: Load test cases by global variant test_cases
    @return: Return test suite
    '''
    suite = TestSuite()
    loader = TestLoader()
    #print loader.loadTestsFromName(u'TestCase.Release.CreateOneRelease')
    tests = loader.loadTestsFromNames(test_cases)
    suite.addTests(tests)
    return suite
#    for test_class in test_cases:
#        tests = loader.loadTestsFromNames(test_cases)
#        suite.addTests(tests)

def initialize(suite_name, type_='case'):
    '''
    @summary: Return tc-list which is one test case list by test case config files
    @param:
        suite_name: Test case config file name
        type_: Return list by test case or module, it will parse all test cases in one module if it is a module
    @return: glocal variant tc_list
    '''
    global tc_list
    abs_path = os.path.abspath(os.path.dirname(__file__)) + os.path.sep + suite_name
    if not os.path.exists(abs_path):
        print "Test suite %s is not exist!" % abs_path
        exit(0)
    xu.load(abs_path)
    if type_ == 'case':
        tc_list = xu.getTestCaseNodes()
    elif type_ == 'module':
        tc_list = xu.get_module_nodes()
    
def createTestCase(suite_name):
    '''
    @summary: Return test case suite according to configration filename
    @param:
        suite_name: Test case configuration file name
    @return: global variant test_cases 
    '''
    for tc in tc_list:
        if tc["run"] != "True":
            continue
        abs_path = os.path.abspath(os.path.dirname(__file__)) + os.path.sep + suite_name
        xu.load(abs_path)
        oper_list = xu.getOperationNodes(tc)
    
        for oper in oper_list:
            clsname =  oper["modulename"] + "." + oper["classname"] 
            print "class name is: %s" % clsname
            modname = oper["modulename"]
            print "module name is: %s" % modname
    #       module = __import__("TestCase"+"."+modname)
    #       cls_instance = getClass(clsname)
            test_cases.append("TestCase."+clsname)

def create_testcase_by_module():
    '''
    @summary: Return test case suite by test case module name, e.g. releas
    @param: global variant tc_list
    @return: global variant test_cases 
    '''
    
    # print tc_list
    for tc in tc_list:
        if tc['run'] == 'True':
            module_file_name = tc['filename']
            print "module name:%s" % module_file_name
            # testcase_file = get_testcase_dir() + module_file_name
            get_testcases_from_module(module_file_name)
        else:
            continue
    
def get_testcases_from_module(module_name):
    '''
    @summary: Return test case suite by test module, e.g. release
    @param module_name: module name
    @return: global vairant test_cases
    '''
    module_path = get_testcase_dir() + module_name
    f = open(module_path)
    for line in f.readlines(): # Find all class name by read each test module
        if re.match("^class", line) and "(BaseTestCase)" in line:
            test_cases.append("TestCase.%s.%s" % (module_name[:-3], line[6:-16]))
    f.close()  

_log_level = None
def get_log_level():
    '''
    @summary: Get current log_level from file GlobalConf
    '''
    global _log_level
    
    if _log_level is None:
        dict_data = load_global_config()
        _log_level = int(dict_data['globalconf']['loglevel']['value'])
    # print _log_level
    return _log_level

def load_global_config(): 
    '''
    @summary: Import global configurations from file GlobalConf.xml by dataload
    @return: Return a dictionary about global configuration
    '''
    global_config_file = get_project_dir() + "TestRun" + os.path.sep + "GlobalConf.xml"
    data_load = dataload(global_config_file)
    return data_load.load()


def get_testcase_dir():
    '''
    @summary: Get Absolute Pathname for test cases directory
    '''
    return get_project_dir() + "TestCase" + os.path.sep

def get_test_result_path():
    '''
    @summary: Get Absolute Pathname to store test results
    '''
    cur_time = time.localtime(time.time())
    format_time = time.strftime('%Y-%m-%d_%H%M%S', cur_time)
    return get_project_dir() + 'Result' + os.path.sep + format_time +\
        '_' + get_exec_type() + '_' + str(len(test_cases)) + '.html'

def get_exec_type():
    '''
    @summary: Get current run type
    '''
    dict_data = load_global_config()
    return dict_data['globalconf']['exec_type']['value']
    
def executeTest():
    '''
    @summary: Trigger Test run
    @param test_cases: Test case suite list
    '''
    global test_cases
    # global _log_level
    
    # btc = BaseTestCase()
    # dict_data = btc.initData()
    # dict_data = load_global_config()
    exec_type = get_exec_type()
    # _log_level = dict_data['globalconf']['loglevel']['value']
    
    if exec_type == 'all':
        # print test_cases
        # curPath = os.path.abspath(os.path.dirname(__file__))
        test_case_dir = get_testcase_dir()
        all_case_file = os.listdir(test_case_dir)
        all_case_module = deepcopy(all_case_file) # 遍历TestCase目录
        #print all_case_module
        for case_file in all_case_file:
            if ".pyc" in case_file:
                all_case_module.remove(case_file)
        all_case_module.remove("__init__.py")
        all_case_module.remove("Base.py")
        all_case_module.remove("SmokeTesting.py")

        for module in all_case_module:
            get_testcases_from_module(module)
        
    elif exec_type == 'module':
        suite_name = 'ModuleConf.xml'
        initialize(suite_name, 'module')
        create_testcase_by_module()
    
    elif exec_type == 'autotest':
        suite_name = 'autotest.xml'
        initialize(suite_name)
        createTestCase(suite_name)
    
    elif exec_type == 'config':
        suite_name = "BasicSuite.xml"
        initialize(suite_name)
        createTestCase(suite_name)
        
    elif exec_type == 'smoke':
        test_cases = ["TestCase.SmokeTesting.SmokeTesting"]
        
    else:
        print "Can't identify the execute type, existing..."
        
    print 'There is(are) %d testcase(s) to execute:' % len(test_cases)
    print test_cases
       
    testSuite = load_tests() 
                
    result_file = get_test_result_path()

    fp = file(result_file, 'wb')
    runner = HTMLTestRunner(
        stream=fp, 
        title=u"PDC Automation Test Report",
        description=(
            u"PDC Automation Test Report\n"
            u'Type of Test Run：%s' % exec_type
        )
    )
    runner.run(testSuite)

if __name__ == "__main__":
    executeTest()

