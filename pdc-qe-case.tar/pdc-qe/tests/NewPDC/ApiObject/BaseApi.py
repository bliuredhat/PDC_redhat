# -*- coding=utf-8 -*-

# ChangeLog:
#-----------------------------------------------------------

from time import sleep

from PDCLIB import PDCLIB
from Utils.PublicMethod import printLog, catchException, retry

class BaseApi(PDCLIB, object):
    '''
    '''
    def __init__(self):
        '''
        @summary:BaseApi
        '''
        pass
            
if __name__ == "__main__":
    pass
