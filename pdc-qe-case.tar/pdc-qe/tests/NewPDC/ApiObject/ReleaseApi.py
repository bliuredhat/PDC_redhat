# -*- coding=utf-8 -*-

"""
"""

# ChangeLog:
# Version    Date            Desc                Author
#----------------------------------------------------------
# V0.1       10/21/2017      Initiation          meli
#----------------------------------------------------------

import time
import socket
from datetime import datetime
from BaseApi import BaseApi
from Utils.PublicMethod import printLog, catchException

class ReleaseApi(BaseApi):
    '''
    '''
    def __init__(self, driver):
        super(ReleaseApi, self).__init__()
    
if __name__ == '__main__':
    pass
