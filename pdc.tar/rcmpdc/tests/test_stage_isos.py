#!/usr/bin/python
# -*- coding: utf-8 -*-


import unittest

import sys
sys.path.append("..")

from productmd import ComposeInfo
from productmd.imagemanifest import Image

from rcm_pdc.stage_isos import StageISOS

MAX_RHN_CATEGORY_LEN=128

def q(data, **kwargs):
    result = []
    scalar = False
    for i in data:
        match = False
        for key, value in kwargs.items():
            if key == "_scalar" and value:
                scalar = True
                continue
            if i[key] == value:
                match = True
            else:
                match = False
                break
        if match:
            result.append(i)
    if scalar:
        if len(result) == 1:
            return result[0]
        if not result:
            raise ValueError("No results match the query")
        raise ValueError("Multiple results match the query: %s" % len(result))
    return result


def get_rhel_ci(compose_type, label=None):
    ci = ComposeInfo()
    ci.product.name = "Red Hat Enterprise Linux"
    ci.product.version = "7.0"
    ci.product.short = "RHEL"
    ci.compose.date = "20130102"
    ci.compose.respin = 5
    ci.compose.type = compose_type
    ci.compose.label = label
    ci.compose.id = ci.create_compose_id()
    return ci


def get_supp_ci(compose_type, label=None):
    ci = ComposeInfo()
    ci.product.name = "Supplementary"
    ci.product.version = "7.0"
    ci.product.short = "Supp"
    ci.product.is_layered = True
    ci.base_product.name = "Red Hat Enterprise Linux"
    ci.base_product.version = "7"
    ci.base_product.short = "RHEL"
    ci.compose.date = "20130102"
    ci.compose.respin = 5
    ci.compose.type = compose_type
    ci.compose.label = label
    ci.compose.id = ci.create_compose_id()
    return ci


def get_satellite_ci(compose_type, label=None):
    ci = ComposeInfo()
    ci.product.name = "Red Hat Satellite"
    ci.product.version = "6.0"
    ci.product.short = "Satellite"
    ci.product.is_layered = True
    ci.base_product.name = "Red Hat Enterprise Linux"
    ci.base_product.version = "7"
    ci.base_product.short = "RHEL"
    ci.compose.date = "20130102"
    ci.compose.respin = 5
    ci.compose.type = compose_type
    ci.compose.label = label
    ci.compose.id = ci.create_compose_id()
    return ci


def get_image(arch, img_type, disc_number, disc_count, format=None):
    img = Image(None)
    img.arch = arch
    img.type = img_type
    img.disc_number = disc_number
    img.disc_count = disc_count
    img.bootable = False
    img.checksums = {"sha256": ""}
    img.mtime = 1
    img.size = 2
    img.format = format or "iso"
    img.path = "path/to/image.img"
    return img


def get_stage_object(options=None):
    stage = StageISOS(None, None, None, options=options)
    stage.repos = [
        {
            "release_id": "rhel-7.0",
            "name": "rhel-7-server-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        },
        {
            "release_id": "rhel-7.0",
            "name": "rhel-7-server-optional-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server-optional",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        },
    ]
    return stage


class TestImageRename(unittest.TestCase):

    def setUp(self):
        self.stage = get_stage_object()

    def tearDown(self):
        # avoid memleaks during tests
        del self.stage

    # NO LABEL
    def test_get_image_name_rhel_no_label(self):
        self.stage.ci = get_rhel_ci(compose_type="test", label=None)
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-kvm.qcow2")

        # p2v
        img = get_image(arch="x86_64", img_type="p2v", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-20130102.t.5-x86_64-p2v.iso")

        # TODO: RHEVH - a variant? an image type? (something like boot.iso?) depends on RHEL variant? has any packages?

    # GA
    def test_get_image_name_rhel_ga(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="GA")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-kvm.qcow2")

    # RC
    def test_get_image_name_rhel_rc(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="RC-1.3")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-x86_64-kvm.qcow2")

    # BETA
    def test_get_image_name_rhel_beta(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="Beta-1.0")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-beta-1-x86_64-kvm.qcow2")

    # BETA
    def test_get_image_name_rhel_beta_unified(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="Beta-1.0")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-7.0-beta-1-x86_64-kvm.qcow2")

    # SNAPSHOT
    def test_get_image_name_rhel_snapshot(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="Snapshot-5.1")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "rhel-server-7.0-snapshot-5-x86_64-kvm.qcow2")

    # ----- SUPPLEMENTARY -----

    # NO LABEL
    def test_get_image_name_supp_no_label(self):
        self.stage.ci = get_supp_ci(compose_type="test", label=None)
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-20130102.t.5-x86_64-kvm.qcow2")

    # GA
    def test_get_image_name_supp_ga(self):
        self.stage.ci = get_supp_ci(compose_type="production", label="GA")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-kvm.qcow2")

    # RC
    def test_get_image_name_supp_rc(self):
        self.stage.ci = get_supp_ci(compose_type="production", label="RC-1.3")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-x86_64-kvm.qcow2")

    # BETA
    def test_get_image_name_supp_beta(self):
        self.stage.ci = get_supp_ci(compose_type="production", label="Beta-1.0")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-beta-1-x86_64-kvm.qcow2")

    # SNAPSHOT
    def test_get_image_name_supp_snapshot(self):
        self.stage.ci = get_supp_ci(compose_type="production", label="Snapshot-5.1")
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-cd.iso")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-dvd.iso")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-source-dvd.iso")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-dvd1.iso")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-dvd2.iso")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-boot.iso")

        # live
        img = get_image(arch="x86_64", img_type="live", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-live.iso")

        # appliance (ec2)
        img = get_image(arch="x86_64", img_type="ec2", disc_number=1, disc_count=1, format="sda.raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-ec2.sda.raw")

        # kvm - raw
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="raw")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-kvm.raw")

        # kvm - qcow2
        img = get_image(arch="x86_64", img_type="kvm", disc_number=1, disc_count=1, format="qcow2")
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "supp-server-7.0-rhel-7-snapshot-5-x86_64-kvm.qcow2")

    # get image label
    def test_get_image_label(self):
        # TODO: fix? should it cover self.stage.get_image_description()?
        self.stage.ci = get_rhel_ci(compose_type="test", label=None)

        # cd
        img = get_image(arch="x86_64", img_type="cd", disc_number=1, disc_count=1)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Binary CD")

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Binary DVD")

        # source dvd
        img = get_image(arch="src", img_type="dvd", disc_number=1, disc_count=1)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Source DVD")

        # dvd1
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=2)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Binary DVD1")

        # dvd2
        img = get_image(arch="x86_64", img_type="dvd", disc_number=2, disc_count=2)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Binary DVD2")

        # boot.iso
        img = get_image(arch="x86_64", img_type="boot", disc_number=1, disc_count=1)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "Boot ISO")

        # p2v
        img = get_image(arch="x86_64", img_type="p2v", disc_number=1, disc_count=1)
        label = self.stage.get_image_label(img)
        self.assertEqual(label, "P2V ISO")

#        # supplementary dvd
#        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
#        label = self.stage.get_image_label(img)
#        self.assertEqual(label, "RHEL 7.0 Supplementary DVD")

    # label override
    def test_label_override(self):
        self.stage = get_stage_object(options={"compose_label": "FooBar-1.2.3"})
        self.stage.ci = get_rhel_ci(compose_type="test", label=None)
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)

        # dvd
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Server", img)
        name = self.stage.get_image_name(img, repo)
        # even if it's a test compose, use the label
        self.assertEqual(name, "rhel-server-7.0-foobar-1.2-x86_64-dvd.iso")

    # get category label
    def test_get_rhn_category_label_production(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label=None)

        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.5 Server (x86_64)")

        repo = q(self.stage.repos, name="rhel-7-server-optional-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.5 Server-optional (x86_64)")

        self.stage.ci = get_supp_ci(compose_type="production", label=None)
        self.stage.repos = [{
            "release_id": "supp-rhel-7.0",
            "name": "rhel-7-server-supplementary-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        }]

        repo = q(self.stage.repos, name="rhel-7-server-supplementary-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Supplementary 7.0 20130102.5 Server for Red Hat Enterprise Linux 7 (x86_64)")

        # TODO: pretty arch names
        # do we really want them? CDN/RHN should look the same of possible

    def test_get_rhn_category_label_production_beta(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="Beta-2.3")

        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 Beta Server (x86_64)")

        repo = q(self.stage.repos, name="rhel-7-server-optional-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 Beta Server-optional (x86_64)")

        self.stage.ci = get_supp_ci(compose_type="production", label="Beta-2.3")
        self.stage.repos = [{
            "release_id": "supp-rhel-7.0",
            "name": "rhel-7-server-supplementary-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        }]

        repo = q(self.stage.repos, name="rhel-7-server-supplementary-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Supplementary 7.0 Beta Server for Red Hat Enterprise Linux 7 (x86_64)")

        # TODO: pretty arch names
        # do we really want them? CDN/RHN should look the same of possible

    def test_get_rhn_category_label_production_rc(self):
        self.stage.ci = get_rhel_ci(compose_type="production", label="RC-2.3")

        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 Server (x86_64)")

        repo = q(self.stage.repos, name="rhel-7-server-optional-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 Server-optional (x86_64)")

        self.stage.ci = get_supp_ci(compose_type="production", label="RC-2.3")
        self.stage.repos = [{
            "release_id": "supp-rhel-7.0",
            "name": "rhel-7-server-supplementary-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        }]

        repo = q(self.stage.repos, name="rhel-7-server-supplementary-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Supplementary 7.0 Server for Red Hat Enterprise Linux 7 (x86_64)")

        # TODO: pretty arch names
        # do we really want them? CDN/RHN should look the same of possible

    def test_get_rhn_category_label_test(self):
        self.stage.ci = get_rhel_ci(compose_type="test", label=None)

        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.t.5 Server (x86_64)")

        repo = q(self.stage.repos, name="rhel-7-server-optional-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.t.5 Server-optional (x86_64)")

        self.stage.ci = get_supp_ci(compose_type="test", label=None)
        self.stage.repos = [{
            "release_id": "supp-rhel-7.0",
            "name": "rhel-7-server-supplementary-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        }]

        repo = q(self.stage.repos, name="rhel-7-server-supplementary-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Supplementary 7.0 20130102.t.5 Server for Red Hat Enterprise Linux 7 (x86_64)")

        # TODO: pretty arch names
        # do we really want them? CDN/RHN should look the same of possible

    def test_get_rhn_category_label_test_unified(self):
        self.stage.ci = get_rhel_ci(compose_type="test", label=None)

        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.t.5 (x86_64)")

        repo = q(self.stage.repos, name="rhel-7-server-optional-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Red Hat Enterprise Linux 7.0 20130102.t.5 (x86_64)")

        self.stage.ci = get_supp_ci(compose_type="test", label=None)
        self.stage.repos = [{
            "release_id": "supp-rhel-7.0",
            "name": "rhel-7-server-supplementary-isos",
            "service": "pulp",
            "arch": "x86_64",
            "content_format": "iso",
            "content_category": "binary",
            "variant_uid": "Server",
            "shadow": False,
            "repo_family": "dist",
            "product_id": None,
        }]

        repo = q(self.stage.repos, name="rhel-7-server-supplementary-isos", _scalar=True)
        label = self.stage.get_rhn_category_label(repo)
        self.assertEqual(label, "Supplementary 7.0 20130102.t.5 for Red Hat Enterprise Linux 7 (x86_64)")

    @unittest.expectedFailure
    def test_max_len_rhn_category_label(self):
        # let's check whether the value changed
        self.assertEqual(MAX_RHN_CATEGORY_LEN, StageISOS.MAX_RHN_CATEGORY_LEN)
        self.stage.ci = get_rhel_ci(compose_type="test", label="RC-99." + (MAX_RHN_CATEGORY_LEN *"9"))
        repo = q(self.stage.repos, name="rhel-7-server-isos", _scalar=True)
        try:
            label = self.stage.get_rhn_category_label(repo)
        except ValueError:
             self.assertEqual(1, 0, "get_rhn_category_label is > %d " % MAX_RHN_CATEGORY_LEN)

    # RC
    def test_get_image_name_satellite_rc(self):
        self.stage.ci = get_satellite_ci(compose_type="production", label="RC-1.3")
        self.stage.repos = [
            {
                "release_id": "satellite-6.0-rhel-7",
                "name": "rhel-7-satellite-isos",
                "service": "pulp",
                "arch": "x86_64",
                "content_format": "iso",
                "content_category": "binary",
                "variant_uid": "Satellite",
                "shadow": False,
                "repo_family": "dist",
                "product_id": None,
            },
            {
                "release_id": "satellite-6.0-rhel-7",
                "name": "rhel-7-capsule-isos",
                "service": "pulp",
                "arch": "x86_64",
                "content_format": "iso",
                "content_category": "binary",
                "variant_uid": "Capsule",
                "shadow": False,
                "repo_family": "dist",
                "product_id": None,
            },
        ]

        # dvd - Satellite
        repo = q(self.stage.repos, name="rhel-7-satellite-isos", _scalar=True)
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Satellite", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "satellite-6.0-rhel-7-x86_64-dvd.iso")

        # dvd - Capsule
        repo = q(self.stage.repos, name="rhel-7-capsule-isos", _scalar=True)
        img = get_image(arch="x86_64", img_type="dvd", disc_number=1, disc_count=1)
        # name = self.stage.get_image_name("x86_64", "Capsule", img)
        name = self.stage.get_image_name(img, repo)
        self.assertEqual(name, "satellite-capsule-6.0-rhel-7-x86_64-dvd.iso")


if __name__ == "__main__":
    unittest.main()
