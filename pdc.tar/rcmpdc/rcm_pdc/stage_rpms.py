#!/usr/bin/env python

import os
import copy

from productmd.rpms import Rpms

import rcm_pdc
from .stage_base import StageBase, link, mkdirs, symlink



class StageRPMS(StageBase):
    content_format = rcm_pdc.content_format.RPM

    def __init__(self, compose, pdc_proxy, logger, options=None):
        super(StageRPMS, self).__init__(compose, pdc_proxy, logger, options)
        self.rpm_manifest.load(rcm_pdc.get_rm_location(self.compose))

    def do_stage(self):
        self._build_info_cache = {}
        self.old_rpm_manifest = Rpms()

        if self.stage_options['prune']:
            self.old_rpm_manifest = Rpms()
            if self.stage_options['prune_against']:
                self.old_rpm_manifest.load(rcm_pdc.get_rm_location(self.stage_options['prune_against']))
            # TODO automatic prune against without compose tool dependency

        # if the prune is in use the all-rpms structure will be in $staging-dir-all-rpms
        for repo in self.repos:
            self.handle_repo(repo, prune=self.stage_options['prune'])

    def prune_repo(self, repo, rpms):
        """
        @param repo - a dict representing pdc repo
        @param rpms - a dict with nevra as keys
        """
        result = copy.copy(rpms)  # let's not alter input
        assert self.old_rpm_manifest, "Expected a populated self.old_rpm_manifest"
        old_rpms_set = set(self.get_related_rpms(repo, prune=False, manifest=self.old_rpm_manifest).keys())
        to_be_pruned = old_rpms_set.intersection(set(result.keys()))
        for key in to_be_pruned:
            del(result[key])
        self.logger.debug("pruned %d rpms in %s" % (len(to_be_pruned), repo['name']))
        return result

    @staticmethod
    def get_related_rpms_simple(repo, manifest, data_glob=None, logger=None):
        """
        @param repo
        """
        result = {}
        package_type = None

        repo_arch = rcm_pdc.get_repo_arch(repo)
        repo_variant = repo['variant_uid']

        try:
            # Cannot use 'if repo_variant not in manifest' as productmd doesn't support that
            manifest[repo_variant]
        except KeyError:
            logger.warning("Variant %s is missing in compose rpm-manifest" % repo_variant)
            return result

        if repo['content_category'] == rcm_pdc.content_category.BINARY:
#            package_type = "package"
            package_type = "binary"
        elif repo['content_category'] == rcm_pdc.content_category.DEBUG:
            package_type = "debug"
        elif repo['content_category'] == rcm_pdc.content_category.SOURCE:
            package_type = "source"

        if repo_arch not in manifest[repo_variant]:
            # The arch doesn't exist in manifest for this variant.
            # Most probably because new compose add support for the arch.
            # In such cases, return empty dict because in this manifest
            # there aren't any packages for the variant.arch combination.
            if logger:
                logger.warning("Arch %s doesn't exist in %s variant (repo %s)" % \
                        (repo_arch, repo['variant_uid'], repo['name']))
            return result

        for source_nevra, source_data in manifest[repo_variant][repo_arch].iteritems():
            if isinstance(source_data, dict) and "path" not in source_data:  # got rpms
                for nevra, data in source_data.iteritems():
                    if data["category"] == package_type and StageBase.content_passes_data_glob(nevra, data_glob):  # just related rpms, e.g. don't put source into binary repo
                        result[nevra] = data

            else:  # srpm
                if source_data["category"] == package_type and StageBase.content_passes_data_glob(source_nevra, data_glob):
                    result[source_nevra] = source_data
        return result

    @staticmethod
    def rpms_dict_to_list(rpms_data):
        """
        used only for static manifest
        """
        result = set()
        for nevra, data in rpms_data.iteritems():
            result.update([os.path.basename(data['path']),])
        return list(result)

    def get_related_rpms(self, repo, prune=False, manifest=None, data_glob=None):
        """
        @param repo
        @param prune=False - prune packages against self.old_rpm_manifest if any
        @param manifest -
        returns list of repo [nevra: {path: relpath, sigkey: sigkey, type: package|debug|source}]

        Function will raise exception if you'll try to stage unsigned bits.
        Please make sure that you always sign all builds.
        """
        if not manifest:
            manifest = self.rpm_manifest
        if not data_glob and "data_glob" in self.stage_options:
            data_glob = self.stage_options['data_glob']

        result = self.get_related_rpms_simple(repo, manifest, data_glob, logger=self.logger)
        if prune:
            return self.prune_repo(repo, result)
        return result

    def handle_rpm(self, rpm_path, staging_dir, create_symlinks=False):
        def best_sigkey(required, available):
            for sigkey in required:
                if sigkey in available:
                    return sigkey
            return None
        full_path = os.path.normpath(os.path.join(self.compose_dir, rpm_path))
        target = os.path.join(staging_dir, os.path.basename(rpm_path))

        if os.path.exists(target):
            self.logger.debug("Link already exist %s -> %s" % (full_path, target))
            return  # Saves so much time on re-execution if sigkeys is in use

        # User manually specified sigkeys
        if self.stage_options['sigkeys']:
            rpminfo = self.koji_session.getRPM(os.path.basename(rpm_path))
            if rpminfo['build_id'] not in self._build_info_cache:
                self._build_info_cache[rpminfo['build_id']] = self.koji_session.getBuild(rpminfo['build_id'])
                # [{'sigkey': 'f21541eb', 'sighash': '0f91617c92546f8ec78f09a4dd7f103f', 'rpm_id': 3917906},  ...]
                avail_sigkeys = [x['sigkey'] for x in self.koji_session.queryRPMSigs(rpm_id=rpminfo['id'])]
                # let's believe that all rpms within build are signed with same set of keys
                # Store only best match of sigkey for already mentioned reason
                self._build_info_cache[rpminfo['build_id']]['sigkey'] = best_sigkey(
                    self.stage_options['sigkeys'], avail_sigkeys)

            sigkey = self._build_info_cache[rpminfo['build_id']]['sigkey']
            buildinfo = self._build_info_cache[rpminfo['build_id']]
            rpm_relpath = None
            rpm_relpath = self.koji_module.pathinfo.signed(rpminfo, sigkey)
            full_path = os.path.join(self.koji_module.pathinfo.build(buildinfo), rpm_relpath)

        self.logger.debug("%s -> %s" % (full_path, target))
        if create_symlinks:
            symlink(full_path, target)
        else:
            link(full_path, target)

    def get_repo_staging_dir(self, repo):
        # get the staging dir which leads to staging/$service-$family/$repo
        staging_dir = super(StageRPMS, self).get_repo_staging_dir(repo)
        if repo['content_category'] == rcm_pdc.content_category.SOURCE:
            return os.path.join(staging_dir, "SRPMS")
        else:
            return os.path.join(staging_dir, "RPMS")

        return staging_dir

    def handle_repo(self, repo, prune=False):
        self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'],
                         repo['content_format'], self.get_repo_name(repo), repo['arch']))
        related_rpms = self.get_related_rpms(repo, prune=prune)
        if related_rpms:
            staging_dir = self.get_repo_staging_dir(repo)
            self.logger.info("%s -> %s" % (self.get_repo_name(repo), staging_dir))
            mkdirs(staging_dir)
            for nevra, data in related_rpms.iteritems():
                self.handle_rpm(data['path'], staging_dir)
        else:
            # if else ... so we skip creation of $staging_dir/$repo if not necessary
            self.logger.info("%s is empty skipping linking (prune=%s)." % (repo['name'], self.stage_options['prune']))
