#!/usr/bin/env python

import copy
from fnmatch import fnmatch
try:
    import json
except ImportError:
    import simplejson as json

import rcm_pdc


# TODO move the import_repo here

class PulpRepo(object):
    RELEASEVER = "releasever"
    BASEARCH = "basearch"

    def __init__(self, repo):
        self.repo_name = None
        self.repo_label = None
        self.basearch = "" # default for cdn-package-manifest
        self.releasever = "" # default for cdn-package-manifest
        self._repo_arch = repo['arch'] # used only for arch detection in repo label
        if isinstance(repo, dict) and 'name' in repo:
            self.repo_name = repo['name']
        elif isinstance(repo, str):
            self.repo_name = repo
        else:
            raise ValueError("uknown data on input '%s'. Expected str or repo hash {'name': ...}" % str(repo))

        self.set_repo_attrs()

    def set_repo_attrs(self):
        data = self.repo_name.split("__")
        self.repo_label = data[0]
        self.repo_label_dotless = data[0].replace("_DOT_", ".") # XXX pulp hack
        nvars = len(data)
        if not data:
            return

        for attr in data[1:]: # data[0] is always repo_label
            if self._repo_arch == attr:
                self.basearch = attr
            else:
                self.releasever = attr.replace("_DOT_", ".")

    def __str__(self):
        return self.repo_name


class Repos(object):
    def __init__(self, logger=None):
        """
        @param filter
        @param data=None - used for returning
        """
        self.data = []
        self.logger = logger

    def __iter__(self):
        # sort data by Variant, service (, type - which is already limited by )
        for repo in self._sort_repos(self.data):
            yield repo

    def __new_from_list(self, data):
        assert isinstance(data, list)
        rep = copy.copy(self)
        rep.data = data
        return rep

    def _sort_repos(self, repositories):
        return sorted(repositories, key=lambda x: (x['variant_uid'], x['service']))

    def get_used_release_ids(self):
        """
        used for verification (if all release_ids exist)
        returns list of release_id
        """
        result = set()
        for repo in self.data:
            result.update([repo['release_id'],])
        return result

    def from_pdc(self, client, release_id, **kwargs):
        kwargs['release_id'] = release_id
        kwargs['page_size'] = -1 # XXX: hopefully will be fixed in pdc
        self._log_info("Getting repos from pdc/%s filters: %s" % (release_id, str(kwargs)))
        # just to note that call returns also read-only items (id) which needs to be ignored in to_pdc()
        self.data = client['content-delivery-repos'](**kwargs)
        assert isinstance(self.data, list), \
            "got invalid data on input expected list got %s" % str(self.data)
        

        

    def check_repo_dict(self, repo_dict):
        """
        @param repo_dict - repo as returned by pdc api
        """
        if repo_dict['service'] in (rcm_pdc.content_service.PULP, rcm_pdc.content_service.CDN,) and "__" not in repo_dict['name']:
            if self.logger:
                self.logger.warning("pulp repo doesn't contain '__' make sure it's valid pulp repo label")

    def from_productdb_json(self, source, release):
        """
        @param source - either json dump or path to json
        @param release
        """
        def translate_service(service):
            if service == "cdn":
                return "pulp"
            return service

        self.data = []
        data = source
        if isinstance(source, str):
            data = rcm_pdc.dump_json(source)

        for variant in sorted(data):
            for arch in sorted(data[variant]):
                product_id = None
                for service in sorted(data[variant][arch]):
                    if service in ('cdn-product-id',):
                        continue
                    for repo_type in sorted(data[variant][arch][service]):
                        product_id = None
                        repo_family = repo_type.split("-")[0]
                        if 'cdn-product-id' in data[variant][arch] and repo_family in data[variant][arch]['cdn-product-id']:
                            product_id = int(data[variant][arch]['cdn-product-id'][repo_family])
                        repo_name = data[variant][arch][service][repo_type]
                        shadow = True if repo_type.endswith("shadow") else False
                        content_format = "rpm"  # default
                        for cf in "iso", "kickstart", "container":
                            if cf in repo_type:
                                content_format = cf
                                break

                        content_category = "binary"  # default
                        for cc in "debug", "source":
                            if cc in repo_type:
                                content_category = cc
                                break

                        hsh = {
                            'release_id': release,
                            'shadow': shadow,
                            'variant_uid': variant,
                            'arch': arch,
                            'repo_family': repo_family,
                            'content_format': content_format,
                            'content_category': content_category,
                            'name': repo_name,
                            'service': translate_service(service),
                            'product_id': product_id
                        }
                        self.check_repo_dict(hsh)
                        self.data.append(hsh)

    def from_json(self, filename):
        fd = open(filename, "r")
        data = json.load(fd)
        for record in data:
            self.check_repo_dict(record)
        self.data = data
        fd.close()

    def delete_all(self, client):
        """
        @param client
        """
        print ("Deleting all repos in bulk.")
        data = [repo['id'] for repo in self.data]
        client['content-delivery-repos']._('DELETE', data)

    def to_json(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(',', ': '))

    def to_pdc(self, client):
        """
        @param proxy
        """
        
        data = copy.deepcopy(self.data)
        
        # get rid of read-only items which can't be passed to pdc during creation
        read_only_attrs = ('id',)
        for item in data:
            for rattr in read_only_attrs:
                if rattr in item.keys():
                    item.pop(rattr)

        print ("Creating all repos in bulk.")
        client['content-delivery-repos']._(data)

    def _log_info(self, msg):
        if self.logger:
            self.logger.info(msg)

    def _log_debug(self, msg):
        if self.logger:
            self.logger.debug(msg)

    def filter(self, filters):
        res = []
        if self.logger:
            self.logger.debug("repos: filters on input %s" % filters)
        for repo in self.data:
            include = True
            if filters:
                for attr, patterns in filters.iteritems():
                    if not (isinstance(patterns, list) or isinstance(patterns, tuple)):
                        patterns = [patterns]
                    oneof = False
                    for pattern in patterns:
                        if pattern is None:
                            self._log_debug("exclude %s because %s == None" % (repo, pattern))
                            include = False
                            break

                        if attr == "fnmatch": # not really repo attr
                            self._log_debug("%s passed condition repo[%s] == %s" % (repo['name'], attr, pattern))
                            fnmatch.fnmatch(repo['name'], pattern)
                            oneof = True
                            continue

                        if isinstance(pattern, bool) and repo[attr] == pattern and include:
                            self._log_debug("%s passed condition repo[%s] == %s" % (repo['name'], attr, pattern))
                            oneof = True
                            continue

                        if (isinstance(pattern, str) or isinstance(pattern, unicode)) and fnmatch(repo[attr], pattern) and include:
                            self._log_debug("%s passed condition repo[%s] == %s" % (repo['name'], attr, pattern))
                            oneof = True
                            continue

                        self._log_debug("%s failed condition repo[%s] == %s" % (repo['name'], attr, pattern))

                    if include and not oneof:
                        include = False
            if include:
                res.append(repo)

        return self.__new_from_list(self._sort_repos(res))
