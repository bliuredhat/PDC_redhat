#!/usr/bin/env python

import csv

from rcm_pdc.repos import PulpRepo

PRODUCTS_CSV_HEADER = ["Active", "ID", "Label", "Name", "Architecture", "Version", "Variant", "Description", "Type"]
CONTENT_CSV_HEADER = ["Active", "ID", "Product ID", "Name", "Label", "Vendor ID", "Download URL", "Type", "GPG Key URL", "Quantity", "Virtual Quantity", "Enabled", "Metadata Expire", "Metadata", "Architecture"]
DEFAULT_ENGPROXY = "qa"

def read_csv(path, header):
    with open(path, "r") as csvfile:
        reader = csv.reader(csvfile)
        header_row = None
        num_rows = 0    # Number of parsed records
        for line_no, row in enumerate(reader, start=1):
            if not row:
                continue
            if row[0] not in ("0", "1"):
                # If row does not start with 0 or 1, it may be a header or an
                # invalid row. If the first non-blank line in the file looks
                # like that, assume it is the header and save it for potential
                # debugging. Otherwise report an error.
                if not header_row and num_rows == 0:
                    header_row = row
                    continue
                raise RuntimeError('Line %d is invalid: %r' % (line_no, row))
            yield dict(zip(header, row))
            num_rows += 1

def read_products_csv(filename, logger=None):
    if logger:
        logger.debug("Reading product records from '%s'" % filename)
    result = {}
    for row in read_csv(filename, header=PRODUCTS_CSV_HEADER):
        row["ID"] = int(row["ID"])
        result[row["ID"]] = row
    return result

def read_content_csv(filename, logger=None):
    if logger:
        logger.debug("Reading content set records from '%s'" % filename)
    result = {}
    for row in read_csv(filename, header=CONTENT_CSV_HEADER):
        row["ID"] = int(row["ID"])
        row["Product ID"] = int(row["Product ID"])
        result[row["Label"]] = row
    return result

class EngProxyCSVWrapper(object):
    def __init__(self, server=DEFAULT_ENGPROXY, logger=None):
        self.server = server
        self.logger = logger
        self._products_csv = "/mnt/redhat/scripts/rel-eng/rcm-metadata/cdn/products-%s.csv" % self.server
        self._content_csv =  "/mnt/redhat/scripts/rel-eng/rcm-metadata/cdn/content-%s.csv" % self.server
        self._all_eng_products_data = {}
        self._all_eng_content_data = {}
        self._load_eng_proxy_data()


    def _load_eng_proxy_data(self):
        self._all_eng_products_data = read_products_csv(self._products_csv, logger=self.logger)
        self._all_eng_content_data = read_content_csv(self._content_csv, logger=self.logger)

    def get_eng_proxy_product_record(self, repo):
        if repo['product_id'] in self._all_eng_products_data:
            return self._all_eng_products_data[repo['product_id']]
        return None

    def get_eng_proxy_content_set_record(self, repo):
        return self._all_eng_content_data[PulpRepo(repo).repo_label_dotless]

    def get_product_name(self, repo):
        assert repo['product_id'], "repo: %s doesn't have any product id assigned" % repo['name']
        record = self.get_eng_proxy_product_record(repo)
        label = record['Label']
        return label
