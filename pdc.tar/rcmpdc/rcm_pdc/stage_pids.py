#!/usr/bin/env python

import os
import glob

import rcm_pdc
from .stage_base import StageBase, mkdirs, copy2


class PIDFactory(object):
    def __init__(self, release, repos, signing_server="dev"):
        self.release = release
        self.repos = repos
        self.signing_server = signing_server

class StagePIDS(StageBase):
    content_format = rcm_pdc.content_format.PID
    pid_filename = "productid"

    def do_stage(self):
        for repo in self.repos:
            self.handle_repo(repo)

    def get_related_content_format(self):
        return [rcm_pdc.content_format.RPM]

    def get_alternate_pid_abs_path(self, repo):
        """
        @param repo
        """
        pem_dir = self.stage_options["pid_from_path"][repo["repo_family"]]
        variant = self.ci.variants[repo['variant_uid']]
        # variant-variant-arch because of quite common Server-Server.x86_64
        patterns = [
            "%s-%s-*.pem" % (repo["variant_uid"], repo["arch"]),
            "%s-%s-%s-*.pem" % (repo["variant_uid"], repo["variant_uid"], repo["arch"])
        ]
        pems = []
        for pattern in patterns:
            pems.extend(glob.glob(os.path.join(pem_dir, pattern)))

        self.logger.debug("Searching for %s within %s" % (patterns, pem_dir))
        if len(pems) > 1:
            self.logger.error("Found multiple pems for %s.%s" % (repo["variant_uid"], repo["arch"]))
            raise ValueError("Found multiple pems for %s.%s. Got %s" % (repo["variant_uid"], repo["arch"], pems))

        if variant.type == "variant" and not pems:
            self.logger.warning("Main variant %s.%s has no productid assigned" % (repo["variant_uid"], repo["arch"]))

        if pems:
            return pems[0]  # handled by if statement above
        return None

    def get_pid_abs_path(self, repo):
        """
        @param repo
        returns path to productid file or None
        """
        if "pid_from_path" in self.stage_options and repo["repo_family"] in self.stage_options["pid_from_path"]:
            self.logger.info("Using custom pid path '%s' for %s.%s" % (self.stage_options["pid_from_path"][repo["repo_family"]], repo["variant_uid"], repo["arch"]))
            return self.get_alternate_pid_abs_path(repo)
        repo_paths = [self.get_repository_dir(repo), os.path.join(self.get_repository_dir(repo), "repodata")]
        for path in repo_paths:
            pid_path = os.path.join(path, "productid")
            self.logger.debug("%s/%s: checking for %s" % (repo['name'], self.content_format, pid_path))
            if os.path.exists(pid_path):
                return pid_path
        return None

    def handle_pid(self, pid_path, staging_dir):
        # let's symlink even when we could practically copy the file
        target_name = os.path.join(staging_dir, self.pid_filename)
        mkdirs(staging_dir)
        self.logger.debug("Copy %s -> %s" % (pid_path, target_name))
        # Exception: always copy since we might be using custom paths for pids
        copy2(pid_path, target_name)

    def get_repo_staging_dir(self, repo):
        return os.path.join(super(StagePIDS, self).get_repo_staging_dir(repo), "PRODUCTID")

    def handle_repo(self, repo):
        # Make it simple: go trough every repository related to repo on input and lookup for productid
        # Nothing should go wrong in this specific part
        # productid is not supported on RHN
        if repo['service'] == rcm_pdc.content_service.RHN:
            self.logger.debug("Skipping %s/%s/%s/%s/%s since it's not supported on RHN" %
                              (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
            return

        if repo["content_category"] != rcm_pdc.content_category.BINARY:
            self.logger.debug("Skipping %s/%s/%s/%s/%s since content_category != BINARY" %
                              (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
            return

        self.logger.info("Processing %s/%s/%s/%s/%s" %
                         (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))

        pid_path = self.get_pid_abs_path(repo)
        if pid_path:
            self.logger.info("%s/pid productid found  %s" % (repo['name'], pid_path))
            self.handle_pid(pid_path, self.get_repo_staging_dir(repo))
