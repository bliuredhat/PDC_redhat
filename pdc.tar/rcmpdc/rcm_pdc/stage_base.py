#!/usr/bin/env python

import os
import sys
import errno
import shutil
import logging
import fnmatch

from productmd.rpms import Rpms
from productmd.images import Images

import koji     # required for --sigkeys only
import rcm_pdc
import rcm_pdc.repos


def mkdirs(path):
    try:
        os.makedirs(path)
    except OSError, ex:
        if ex.errno != errno.EEXIST:
            raise


def link(src, dst):
    """
    @param src
    @param dst
    """
    mkdirs(os.path.dirname(dst))

    # Creating a hard link to a relative symlink is wrong. If `src` is a
    # relative symlink, we resolve it and create a hardlink to its target
    # instead.
    #
    # WARNING: If the symlink points to another filesystem, this will break.
    if os.path.islink(src):
        target = os.readlink(src)
        if not target.startswith('/'):
            src = os.path.join(os.path.dirname(src), target)

    try:
        os.link(src, dst)
    except OSError, ex:
        sys.stderr.write("Failed to link source: %s dest:  %s" % (src, dst))
        if ex.errno != errno.EEXIST:
            raise


def copy2(src, dst):
    """
    @param src
    @param dst
    """
    mkdirs(os.path.dirname(dst))
    shutil.copy2(src, dst)


def symlink(src, dst):
    """
    @param src
    @param dst
    """
    mkdirs(os.path.dirname(dst))
    try:
        os.symlink(src, dst)
    except OSError, ex:
        if ex.errno != errno.EEXIST:
            raise

def repo_debug_str(repo):
    shadow_str = ""
    if repo['shadow']:
        shadow_str = "/shadow"
    return "%s/%s/%s/%s%s" % (repo['repo_family'], repo['service'], repo['content_format'], repo['name'], shadow_str)

class StageBase(object):
    content_format = None
    staging_reldir = "staging"

    def __init__(self, compose, pdc_proxy, logger, options=None):
        if not logger:
            self.logger = logging.getLogger()
        else:
            self.logger = logger
        self._koji_profile = options['koji_profile']
        self._koji_module = koji.get_profile_module(self._koji_profile)
        opts = {}

        krbservice = getattr(self.koji_module.config, "krbservice", None)
        if krbservice:
            opts["krbservice"] = krbservice
        self._koji_session = koji.ClientSession(self.koji_module.config.server, opts=opts)
        self._pdc_proxy = pdc_proxy
        self.compose = compose
        self._compose_dir = None
        # supported options:
        #  * compose_label - override existing compose label
        self.stage_options = options or {}

        if compose:
            # for tests - to avoid reading metadata
            # load rpm manifest and image-manifest in phases which are using it
            # allows to stage e.g. productids for metadata-less composes
            self.rpm_manifest = Rpms()
            self.image_manifest = Images()

            self.compose_dir = os.path.normpath(os.path.join(self.compose, "compose"))

    @property
    def koji_module(self):
        return self._koji_module

    @property
    def koji_session(self):
        return self._koji_session

    @property
    def pdc_proxy(self):
        return self._pdc_proxy

    @property
    def compose_label(self):
        label = self.stage_options.get("compose_label", None)
        if label is not None:
            return label
        return self.ci.compose.label

    def get_info(self):
        assert self.compose
        self.ci = rcm_pdc.get_compose_info(self.compose)
        # use provided override for release_id
        self.release_id = self.stage_options.get("release_id", rcm_pdc.get_release_id_from_compose(self.compose))
        # TODO: add self.release and self.product, self.base_product

    def get_variant_from_repo(self, repo):
        return self.ci.variants[repo['variant_uid']]

    def get_repository_dir(self, repo):
        variant = self.get_variant_from_repo(repo)
        compose_dir = rcm_pdc.get_compose_dir(self.compose)
        if repo['content_category'] == rcm_pdc.content_category.BINARY:
            return os.path.join(compose_dir, variant.paths.repository[repo['arch']])

        elif repo['content_category'] == rcm_pdc.content_category.DEBUG:
            return os.path.join(compose_dir, variant.paths.debug_repository[repo['arch']])

        elif repo['content_category'] == rcm_pdc.content_category.SOURCE:
            return os.path.join(compose_dir, variant.paths.source_repository[repo['arch']])

        raise NotImplementedError("'%s' was not implemented" % repo['content_category'])

    def get_repo_name(self, repo):
        """
        @param repo - as in pdc
        just in case that we'd need some manipulation
        WARNING: any repo manipulation is highly unwanted!
        """
        return repo['name']

    @staticmethod
    def content_passes_data_glob(content, data_globs=[]):
        """
        This function simply checks whether user didn't specify --data-glob
        and if so then it checks whether the data passes it
        """
        if not data_globs:
            return True

        for pattern in data_globs:
            if fnmatch.fnmatch(content, pattern):
                return True
        return False

    @staticmethod
    def get_stage_root(compose_dir, override=None):
        """
        @param compose_dir - for external calls
        @param override
        """
        if override:
            return override
        return os.path.join(compose_dir, StageBase.staging_reldir)

    def get_service_staging_dir(self, service, repo_family, content_format=None, shadow=False):
        """
        @param service
        @param family
        Note: whole idea is to minimize number of pushes in general
        so I'd like to merge as many staging dirs as possible.

        this "merge" is disabled if user specified self.stage_options.content_format

        adds suffix -$suffix in case that --suffix was specified
        """
        result = None
        if not content_format:
            content_format = self.content_format
        # Multiple destinations might make sense in order to minimize number of pushes

        common_path = os.path.join(self.get_stage_root(self.compose, override=self.stage_options['staging_dir']), repo_family)

        # {$dirname: [$service : content_format], }
        mutual_paths = {
            rcm_pdc.content_service.RHN: [
                rcm_pdc.content_format.RPM,
            ],
            rcm_pdc.content_service.PULP: [
                rcm_pdc.content_format.RPM,
                rcm_pdc.content_format.PID,
                rcm_pdc.content_format.COMPS,
                rcm_pdc.content_format.ISO,
                rcm_pdc.content_format.QCOW,
            ],
        }

        # return $compose/staging/$service and let pub/push-staged handle rest
        if not self.stage_options['content_format'] and service in mutual_paths and self.content_format in mutual_paths[service]:
            result = os.path.join(common_path, service)
        else:
            # user specified content format or data can't be processed (grouped) via pub/push-staged !
            result = os.path.join(common_path, "%s-%s" % (service, self.content_format))

        if shadow:
            result = "%s-%s" % (result, "shadow")

        if self.stage_options['suffix']:  # suffix needs to be at the very end
            # useful for hotfixes
            result = "%s-%s" % (result, self.stage_options['suffix'])
        return result

    def get_repo_staging_dir(self, repo):
        """
        @param repo
        get the staging dir which leads to staging/$service-$family/$repo
        """
        return os.path.join(self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow']), repo['name'])

    def get_related_content_format(self):
        """
        this function is supposed to be used only for filtering relevant repos
        We still want to treat self.content_format as the actual content_format
        """
        return [self.content_format, ]

    def _release_has_htb_repos(self):
        """
        Returns true if self.release_id has any htb repos mapped
        """
        # Query pdc, local repos might have applied filters (e.g. just beta)
        repos = rcm_pdc.repos.Repos(logger=self.logger)
        repos.from_pdc(self.pdc_proxy, self.release_id, repo_family=rcm_pdc.repo_family.HTB)
        if repos:
            return True
        return False

    def get_related_families(self):
        if self.stage_options['repo_family']:
            return self.stage_options['repo_family']

        htb = self._release_has_htb_repos()
        milestone = None
        families = []
        if self.compose_label:
            milestone = self.compose_label.split("-")[0].lower()

        if milestone in ('rc',):
            families = [rcm_pdc.repo_family.DIST]
            if htb:
                families.append(rcm_pdc.repo_family.HTB)
        elif milestone in ('alpha', 'develphaseexit'):
            families = [rcm_pdc.repo_family.BETA] # for testing on QA
        elif milestone in ('beta',):
            # Stage as Beta and HTB in case that htb repos are defined
            families = [rcm_pdc.repo_family.BETA]
            if htb:
                families.append(rcm_pdc.repo_family.HTB)
        elif milestone in ('snapshot', ):
            # Stage as HTB in case that htb repos are defined otherwise keep staging as beta
            families = [rcm_pdc.repo_family.BETA]
            if htb:
                families = [rcm_pdc.repo_family.HTB] # return htb instead

        # We don't ship unlabelled composes (test/nightly)
        # so families == [] -> filter repos won't return any repos
        self.logger.debug("Got following repo families '%s' for following label '%s'" % (families, self.compose_label))
        return families

    def get_mapping(self):
        self.logger.info("Gathering mapping for %s/%s from pdc" % (self.release_id, self.content_format))
        repos = rcm_pdc.repos.Repos(logger=self.logger)
        # query relevant repos for release & StageClass -> this will prevent pdc from returning multipage results
        repos.from_pdc(self.pdc_proxy, self.release_id, content_format=self.get_related_content_format())
        # These filters doesn't have to contain content_format as long as line above already filters them
        filters = rcm_pdc.repo_filters_from_opts(self.stage_options)
        if "content_format" in filters:
            filters.pop("content_format")  # filtered above + it makes issues since content_format is pid while related format is rpm
        filters['repo_family'] = self.get_related_families()
        self.repos = repos.filter(filters)
        if not self.repos:
            self.logger.error("get_mapping: no repo matched filters: %s" % filters)
        else:
            for repo in self.repos:
                self.logger.debug("get_mapping found: %s" % repo['name'])
            self.logger.info("Found %d repos" % len(self.repos.data))

    def stage(self):
        self.logger.info("Handling %s" % self.content_format)
        self.get_info()
        self.get_mapping()
        self.do_stage()
        self.tests()

    def do_stage(self):
        raise NotImplementedError("please override me")

    def tests(self):
        self.logger.info("No Tests for %s" % self.content_format)
