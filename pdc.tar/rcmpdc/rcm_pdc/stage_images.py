#!/usr/bin/env python

import os

import rcm_pdc
from .stage_base import StageBase, link, mkdirs, symlink

try:
    import simplejson as json
except ImportError:
    import json

class PubMapfile(object):
    def __init__(self, version='0.2'):
        assert isinstance(version, str)
        self._version = version
        if self._version in ('0.2', ):
            self._content = {
                'header': {
                    'version': self._version,
                },
                'payload': {
                    'files': [],
                }
            }
        else:
            raise NotImplementedError("Support for version '%s' is not implemnted" % self._version)

    def isEmpty(self):
        return not bool(self._content['payload']['files'])

    def addEntry(self, entry):
        """
        @param entry
        """
        def checkEntry(entry):
            allowed = ('relative_path', 'filename', 'sha256sum', 'version', 'attributes',)
            for item in entry.keys():
                if item not in allowed:
                    raise AttributeError("checkEntry: Unsupported attribute '%s'" % item)

        def checkAttributes(attributes):
            allowed = ('description',)
            for item in attributes.keys():
                if item not in allowed:
                    raise AttributeError("checkAttributes: Unsupported attribute '%s'" % item)
        checkEntry(entry)
        checkAttributes(entry['attributes'])

        if self.getVersion() in ("0.2",):
            if entry not in self._content['payload']['files']:
                self._content['payload']['files'].append(entry)

    def fromJSON(self, data):
        """Load entries from a JSON"""

        # Check version of data
        version = data.get("header", {}).get("version")
        if version != self._version:
            raise AttributeError("Version '%s' of '%s' doesn't match expected version '%s'" %
                    version, fn, self._version)

        # Load entries from the file
        entries = data.get("payload", {}).get("files", [])
        for entry in entries:
            self.addEntry(entry)

    def load(self, fn):
        """Load entries from an existing pub-mapfile.json"""

        # Load the file
        f = open(fn, "r")
        content = json.load(f)

        # Load the data
        self.fromJSON(content)

    def getVersion(self):
        return self._version

    def toJSON(self):
        return json.dumps(self._content, sort_keys=True, indent=4, separators=(',', ': '))

    def write(self, dest):
        fd = open(dest, "w")
        fd.write(self.toJSON())
        fd.close()
        return dest

class StageImages(StageBase):
    content_format = rcm_pdc.content_format.ISO

    def __init__(self, compose, pdc_proxy, logger, options=None):
        super(StageImages, self).__init__(compose, pdc_proxy, logger, options)
        self.image_manifest.load(rcm_pdc.get_im_location(self.compose))

    def do_stage(self):
        # all isos ... there is some action required so better to keep list of all first

        for repo in self.repos:
            self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
            self.handle_repo(repo)

    def get_related_images(self, repo, image_types=[]):
        """
        @param repo
        @param image_types = []
        returns list of repo [image_name: {path: relpath, sigkey: sigkey, type: binary|debug|source}]
        """
        result = []
        try:
            if rcm_pdc.get_repo_arch(repo) not in self.image_manifest[repo['variant_uid']]:
                self.logger.debug("Variant %s.%s has no recods in image manifest. Skipping." % (repo['variant_uid'], rcm_pdc.get_repo_arch(repo, source=True)))
                return result
        except KeyError:  # image_manifest does not support has_key or in
            return result

        for image in self.image_manifest[repo['variant_uid']][repo['arch']]:
            if image.arch != rcm_pdc.get_repo_arch(repo, source=True):
                # In binary arch we want to skip source isos, and for source
                # iso repositories we want to skip binary isos.
                continue
            self.logger.debug("Processing image %s" % image.path)
            if image_types and (image.type not in image_types):
                self.logger.warning("%s/%s image %s skipped due image_types = %s" % (repo['name'], self.content_format, image.path, str(image_types)))
            else:
                result.append(image)
        return result

    def get_image_relative_path(self, repo, image_abspath):
        """
        @param repo
        @param image_abspath
        returns relative path from within the staging directory
        """
        return os.path.relpath(image_abspath, self.get_service_staging_dir(service=repo['service'], repo_family=repo['repo_family'], shadow=repo['shadow']))

    def handle_image(self, repo, image, create_symlinks=False):
        self.logger.info("Handling %s" % os.path.basename(image.path))
        repo_staging_dir = self.get_repo_staging_dir(repo)
        full_path = os.path.join(self.compose_dir, image.path)
        self.logger.debug("%s -> %s" % (full_path, repo_staging_dir))
        target = os.path.join(repo_staging_dir, os.path.basename(image.path))
        mkdirs(repo_staging_dir)
        if create_symlinks:
            symlink(full_path, target)
        else:
            link(full_path, target)

    def handle_repo(self, repo):
        images = self.get_related_images(repo)
        if not images:
            return
        for image in images:
            self.handle_image(repo, image)
