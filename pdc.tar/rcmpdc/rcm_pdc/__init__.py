#!/usr/bin/env python

import os
import sys
import logging
import logging.handlers
import inspect
from optparse import OptionParser, OptionGroup
try:
    import simplejson as json
except ImportError:
    import json

import requests
import productmd.composeinfo
import productmd.common
import requests_kerberos
from beanbag import BeanBagException
from pdc_client import PDCClient

from . import repos


class repo_family(object):
    """
    TODO: get rid of this when PDC-457 is closed
    """
    DIST = "dist"
    EUS = "eus"
    BETA = "beta"
    HTB = "htb"


class content_format(object):
    RPM = "rpm"
    ISO = "iso"
    KICKSTART = "kickstart"
    COMPS = "comps"
    PID = "pid"
    CDN_PACKAGE_MANIFEST = "package-manifest"
    DOCKER = "docker"
    QCOW = "qcow2"

class content_service(object):
    RHN = "rhn"
    PULP = "pulp"
    FTP = "ftp"
    CDN = "pulp"  # compat
    REGISTRY = "registry"  # registry-docker, possibly redhat as well in the future


class content_category(object):
    SOURCE = "source"
    BINARY = "binary"
    DEBUG = "debug"

DEFAULT_KOJI_PROFILE = "brew"
DEFAULT_PDC_INSTANCE = 'prod'

DEFAULT_RHN_USER = "rhel-admin"
DEFAULT_PULP_USER = "admin"

DEFAULT_RHN_SERVER = "qa"
DEFAULT_PULP_SERVER = "qa"


UPDATE_RELEASE_TYPES = ('eus', 'aus', 'tus', 'e4s')
class RCMPDCClient(PDCClient):
    """
    PDCClient enhanced by some useful functions and integration with productmd
    """

    def __init__(self, pdc, insecure, ca_cert):
        ssl_verify = ca_cert or not insecure
        if insecure:
            requests.packages.urllib3.disable_warnings(
                requests.packages.urllib3.exceptions.InsecureRequestWarning)
        PDCClient.__init__(self, pdc, ssl_verify=ssl_verify)

    def get_release(self, release_id=None):
        try:
            return self.releases[release_id]()
        except BeanBagException:
            return None # Release not found

    def compose_import_rpms(self, release_id, compose, logger=None):
        """
        @param compose
        @param logger
        """
        dumped_ci = dump_compose_info(compose)
        dumped_rm = dump_rpm_manifest(compose)
        data = {
            'release_id': release_id,
            'composeinfo': dumped_ci,
            'rpm_manifest': dumped_rm,
        }
        logger.debug("Calling %s(%s ...)" % (self['compose-rpms/'], str(data)[:100]))
        self['compose-rpms/'](data)

    def compose_import_images(self, release_id, compose, logger=None):
        """
        @param compose
        @param logger
        """
        dumped_ci = dump_compose_info(compose)
        dumped_im = dump_image_manifest(compose)
        print dumped_im
        data = {
            'release_id': release_id,
            'composeinfo': dumped_ci,
            'image_manifest': dumped_im,
        }
        logger.debug("Calling %s(%s ...)" % (self['compose-images/'], str(data)[:100]))
        import beanbag
        try:
            self['compose-images/'](data)
        except BeanBagException, e:
            print e.response.text
            raise

    def create_product_from_compose(self, compose):
        """
        @param compose
        Note: this creates both product and product version
        """
        ci = dump_compose_info(compose)
        self.rpc.release['import-from-composeinfo/'](ci)

def get_attributes_values(cls):
    objattrs = dir(type('dummy', (object,), {}))
    return [item[-1]
            for item in inspect.getmembers(cls)
            if item[0] not in objattrs]

def get_repo_arch(repo, source=False):
    """
    @param repo
    @param source=False - return arch = "src"  for content_category=source
    """
    if source and repo['content_category'] == content_category.SOURCE:
        return "src"

    return repo['arch']


def ensure_unique_log_path(path):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    while os.path.exists(path):
        p = path.replace(".log", "")
        idot = p.rfind(".")
        if idot:
            try:
                ver = int(p[idot+1:])
                p = "%s.%d" % (p[:idot], ver+1)
            except ValueError:
                p += ".0"
        else:
            p += ".0"
        path = p + ".log"
    return path


def get_logger(prog_name, debug=False, log_filename=None, log_level_stream=logging.INFO,
               log_level_file=logging.DEBUG):
    common_formatter = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logger = logging.getLogger(prog_name)
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(common_formatter)
    ch = logging.StreamHandler()
    ch.setLevel(log_level_stream)
    ch.setFormatter(formatter)
    if debug:
        ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    if log_filename:
        fh = logging.handlers.TimedRotatingFileHandler(log_filename, when="midnight", backupCount=7)
        fh.setLevel(log_level_file)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger


def has_ticket():
    """Checks to see if the user has a valid kerberos ticket.
    From: http://stackoverflow.com/a/4273052
    """
    try:
        import krbV
    except ImportError:
        logging.warn("python-krbV not installed!")
        logging.warn("Proceeding anyway")
        return True

    ctx = krbV.default_context()
    cc = ctx.default_ccache()
    try:
        cc.principal()
        retval = True
    except krbV.Krb5Error:
        retval = False

    return retval


def exit_on_missing_ticket(exit_code=1):
    """
    @param exit_code=1
    """
    if not has_ticket():
        sys.stderr.write("Missing kerberos ticket. Exiting\n")
        raise SystemExit(exit_code)


def get_product_version_from_compose(compose):
    """
    @param compose
    """
    ci = get_compose_info(compose)
    return "-".join([ci.release.short.lower(), ci.release.version.split(".")[0]])  # remove .1 from 7.1 ...

def get_compose_dir(compose):
    if os.path.basename(compose) != "compose":
        return os.path.join(compose, "compose")
    return compose

def get_release_id_from_compose(compose):
    """
    @param compose
    """
    ci = get_compose_info(compose)

    args = dict(
        short=ci.release.short.lower(),
        version=ci.release.version,
        type=ci.release.type
    )

    if ci.release.is_layered:
        args.update(dict(
            bp_short=ci.base_product.short.lower(),
            bp_version=ci.base_product.version,
            bp_type=ci.base_product.type
        ))

    return productmd.common.create_release_id(**args)


def dump_json(filename):
    """
    @param filename
    """
    json_path = filename
    assert os.path.exists(json_path), "%s doesn't exist." % json_path
    fd = open(json_path, "r")
    data = json.load(fd)
    fd.close()
    return data


def get_ci_location(compose):
    return os.path.join(compose,"compose", "metadata", "composeinfo.json")

def get_metadata_dir(compose):
    opts = [os.path.join("compose", "metadata"), "metadata"]
    for opt in opts:
        dirname = os.path.join(compose, opt)
        if os.path.exists(dirname):
            return dirname
    raise IOError("Folder compose/metadata or metadata not found")

def get_im_location(compose):
    dirname = get_metadata_dir(compose)
    for filename in ['images.json', 'image-manifest.json']:
        path = os.path.join(dirname, filename)
        if os.path.exists(path):
            return path
    raise IOError("Unable to find images.json/image-manifest.json")

def get_rm_location(compose):
    dirname = get_metadata_dir(compose)
    for filename in ['rpms.json', 'rpm-manifest.json']:
        path = os.path.join(dirname, filename)
        if os.path.exists(path):
            return path
    raise IOError("Unable to find rpms.json/rpm-manifest.json")

def get_compose_info(compose):
    ci = productmd.composeinfo.ComposeInfo()
    ci.load(get_ci_location(compose))
    return ci

def get_im(compose):
    ci = productmd.composeinfo.ComposeInfo()
    ci.load(get_ci_location(compose))
    return ci

def get_rm(compose):
    ci = productmd.composeinfo.ComposeInfo()
    ci.load(get_ci_location(compose))
    return ci


def dump_compose_info(compose):
    """
    @param compose
    """
    return dump_json(get_ci_location(compose))


def dump_rpm_manifest(compose):
    """
    @param compose
    """

    return dump_json(get_rm_location(compose))


def dump_image_manifest(compose):
    """
    @param compose
    """

    return dump_json(get_im_location(compose))

def update_compose_location(client, compose, location=None, protocol="http"):
    ci = get_compose_info(options.compose)
    data = {"arch": None, "compose": ci.id, "location": tree_location, "scheme": name,
    "url": url, "variant": variant, "synced_content": []}

#    client['compose-tree-locations'] =

def repo_filters_from_opts(opts):
    if not isinstance(opts, dict):
        opts = opts.__dict__

    filters = {}
    keys = ['repo-family', 'content-format', 'service', 'variant-uid', 'arch', 'content-category']
    for key in keys:
        key_t = key.replace("-", "_")
        if key_t in opts and opts[key_t]:
            val = opts[key_t]

            filters[key_t] = val
    return filters

def get_engids_from_parent_product(client, release):
    """
    Attributes:
        client: rcm_pdc instance
        release: release dict from pdc

    Returns:
        unique list of engids of all active releases of given product_version
    Example:
        rcm_pdc.get_engids_from_parent_release(client, client.get_release('supp-7.4@rhel-7'))
        [68, 69, 71, 72, 74, 76, 279]
    """
    releases = client.get_paged(client['releases'], product_version=release['product_version'],
            release_type=release['release_type'], active=True)
    pids = set()
    for release in releases:
        repositories = repos.Repos()
        repositories.from_pdc(client, release['release_id'])
        for repo in repositories:
            if repo['product_id']:
                pids.add(repo['product_id'])
    return list(pids)

def get_common_option_parser(usage=None, rhn=True, pulp=True, service=True):
    """
    Attributes:
        usage - override default usage
        rhn - add rhn server/user/password
        pulp - add pulp server/user/password
        service - add --service (in case that script supports multiple)
                  This is not required if both rhn and cdn
                  are set to True
    """
    parser = OptionParser(usage=usage)
    # mandatory opts
    parser.add_option(
        "--release-id",
        help="Override release (rhel-6.7-beta or supp-7.4-eus@rhel-7)"
    )
    parser.add_option("--compose", help="Use one of --release-id or --compose")
    parser.add_option(
        "--pdc",
        metavar="PDC_SERVER_URL",
        default=DEFAULT_PDC_INSTANCE,
        help="PDC instance shortcut or url [%default]",
    )
    parser.add_option(
        "--insecure",
        action="store_true",
        help="Disable SSL certificate verification",
    )
    parser.add_option(
      "--ca-cert",
      help="Path to CA certificate file or directory",
      metavar="CA_CERT",
    )
    group = OptionGroup(parser, "Filters (only for dump)")
    group.add_option(
        "--variant-uid",
        action="append",
        help="Limit cleanup to variant (fnmatch)",
    )
    group.add_option(
        "--arch",
        action="append",
        help="Limit arches",
    )
    # user might want to skip service if it's only e.g. pulp specific tool
    if service or (rhn and pulp):
        group.add_option(
            "--service",
            action="append",
            default=[],
            help="Limit services to: %s" % ", ".join(get_attributes_values(content_service)),
        )
    group.add_option(
        "--repo-family",
        action="append",
        default=[],
        help="Limit repo family: %s" % ", ".join(get_attributes_values(repo_family)),
    )
    group.add_option(
        "--content-format",
        action="append",
        default=[],
        help="Limit content format: %s" % ", ".join(get_attributes_values(content_format)),
    )
    group.add_option(
        "--content-category",
        action="append",
        default=[],
        help="Limit content category: %s" % ", ".join(get_attributes_values(content_category)),
    )
    group.add_option(
        "--shadow",
        action="store_true",
        help="Clear only shadow repositories",
    )
    group.add_option(
        "--regexp",
        action="append",
        help="Reg-exp for repositories",
    )
    parser.add_option_group(group)
    if rhn:
        rhn_group = OptionGroup(parser, "Service settings (rhn/pulp)")
        rhn_group.add_option(
          "--rhn-server",
          default=DEFAULT_RHN_SERVER,
          help="default is %s" %DEFAULT_RHN_SERVER ,
          metavar="ENV",
        )

        rhn_group.add_option(
          "--rhn-user",
          default=DEFAULT_RHN_USER,
          help="default is %s" % DEFAULT_RHN_USER,
          metavar="USER",
        )
        rhn_group.add_option(
          "--rhn-password",
          metavar="PASSWORD",
        )
        parser.add_option_group(rhn_group)

    if pulp:
        pulp_group = OptionGroup(parser, "Service settings (rhn/pulp)")
        pulp_group.add_option(
          "--pulp-server",
          default=DEFAULT_PULP_SERVER,
          help="default is %s" % DEFAULT_PULP_SERVER,
          metavar="ENV",
        )
        pulp_group.add_option(
          "--cdn-server",
          default=DEFAULT_PULP_SERVER,
          help="default is %s" % DEFAULT_PULP_SERVER,
          metavar="ENV",
        )
        pulp_group.add_option(
          "--eng-server",
          default=DEFAULT_PULP_SERVER,
          help="default is %s" % DEFAULT_PULP_SERVER,
          metavar="ENV",
        )

        pulp_group.add_option(
          "--pulp-user",
          default=DEFAULT_PULP_USER,
          help="default is %s" % DEFAULT_PULP_USER,
          metavar="USER",
        )
        pulp_group.add_option(
          "--pulp-password",
          metavar="PASSWORD",
        )
        parser.add_option_group(pulp_group)

    return parser

def test_productmd_version():
    try:
        import productmd.rpms
        import productmd.images
    except ImportError:
        raise RuntimeError("Old internal-only productmd detected.Use upstream productmd with rcmpdc https://github.com/release-engineering/productmd")

test_productmd_version() # Raise exception when somebody uses old productmd with rcmpdc
