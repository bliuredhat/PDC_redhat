#!/usr/bin/env python

import os
import glob

import rcm_pdc
from .stage_base import StageBase, link, mkdirs, symlink

class StageCOMPS(StageBase):
    content_format = rcm_pdc.content_format.COMPS
    upload_script_filename = "upload-comps.sh"

    def do_stage(self):
        self.upload_script_dests = set()
        for repo in self.repos:
            self.handle_repo(repo)

        self.write_rhn_upload_scripts()

    def write_rhn_upload_scripts(self):
        for staging_dir in self.upload_script_dests:
            target = os.path.join(staging_dir, self.upload_script_filename)
            mkdirs(staging_dir)
            fd = open(target, "w")
            fd.write("#!/bin/bash\nset -x\nset -e\n/mnt/redhat/scripts/rel-eng/utility/rhn/comps_push.sh %s\n" % staging_dir)
            fd.close()
            os.chmod(target, 0755)

    def get_related_content_format(self):
        return [rcm_pdc.content_format.RPM]

    def get_repo_staging_dir(self, repo):
        # rhn is not processed by pub
        if repo['service'] == rcm_pdc.content_service.RHN:
            return super(StageCOMPS, self).get_repo_staging_dir(repo)

        return os.path.join(super(StageCOMPS, self).get_repo_staging_dir(repo), "COMPS")

    def handle_comps(self, repo, comps_files, create_symlinks=False):
        """
        @param repo
        @param comps_files - a list of abspaths to comps files
        @param create_symlinks=False
        """
        if isinstance(comps_files, str):
            comps_files = [comps_files]

        # Let's add comps file into staging structure for both pulp and rhn
        # However pub push-staged --target *cdn* currently skips it
        # while cds/push-staged knows how to handle it

        target_dir = self.get_repo_staging_dir(repo)
        if comps_files and repo["service"] == rcm_pdc.content_service.RHN:
            self.upload_script_dests.add(self.get_service_staging_dir(repo["service"], repo["repo_family"], shadow=repo["shadow"]))

        for cf in comps_files:
            mkdirs(target_dir)
            target = os.path.basename(cf)
            target = target[target.find("comps"):]
            target = os.path.join(target_dir, target)
            self.logger.info("linking %s -> %s" % (cf, target))
            if create_symlinks:
                symlink(cf, target)
            else:
                link(cf, target)

    def handle_repo(self, repo):
        self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
        target_dir = self.get_repo_staging_dir(repo)
        self.logger.debug("%s -> %s" % (self.get_repo_name(repo), target_dir))
        comps_glob = os.path.join(self.get_repository_dir(repo), "repodata", "*comps*.xml")
        comps = glob.glob(comps_glob)
        self.logger.debug("glob.glob(%s) -> '%s'" % (comps_glob, str(comps)))
        self.handle_comps(repo, comps)
