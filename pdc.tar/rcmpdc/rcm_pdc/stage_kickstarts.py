#!/usr/bin/env python

import os

import productmd
import productmd.treeinfo

import rcm_pdc
from .stage_base import StageBase, repo_debug_str, symlink, link, mkdirs


def relative_path(root, path):
    return os.path.relpath(path, root)

def modify_treeinfo(path):
    """
    @param path
    returns new TreeInfo object
    """
    ti = productmd.treeinfo.TreeInfo()
    ti.load(path)

    boot_iso_paths = set()
    for platform in ti.images.images:
        if "boot.iso" in ti.images.images[platform]:
            boot_iso_paths.add(ti.images.images[platform].pop("boot.iso"))

    # remove boot.iso from checksums
    for boot_iso_path in boot_iso_paths:
        if boot_iso_path in ti.checksums.checksums.keys():
            del ti.checksums.checksums[boot_iso_path]

    return ti

class StageKICKSTARTS(StageBase):
    content_format = rcm_pdc.content_format.KICKSTART
    rhn_upload_script_filename = "upload-ks.sh"
    rhn_register_script_filename = "register-ks.sh"
    rhn_all_script_filename = "upload-and-register-ks.sh"

    def do_stage(self):
        self.rhn_scripts = {}
        for repo in self.repos:
            self.handle_repo(repo)

        # write scripts
        for target, repos in self.rhn_scripts.iteritems():
            self.create_rhn_scripts_sh(target, repos)

    def handle_repo(self, repo):
        self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
        target_dir = self.get_repo_staging_dir(repo)
        if repo['service'] == rcm_pdc.content_service.RHN:
            script_dir = self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow'])
            self.rhn_scripts.setdefault(os.path.normpath(script_dir), []).append(repo)
        self.logger.debug("%s -> %s" % (self.get_repo_name(repo), target_dir))
        self.link_ks_tree(repo)

    def get_repo_staging_dir(self, repo):
        """
        @param repo
        get the staging dir which leads to staging/$service-$family/$repo
        """
        if repo['service'] == rcm_pdc.content_service.RHN:
            target = self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow'])
            target = os.path.join(target, "pub", "rhn", "kickstart", "ks-%s-%s" % (repo["name"], self.ci.release.version))
            return target

        return super(StageKICKSTARTS, self).get_repo_staging_dir(repo)

    def get_tree_files(self, repo):
        variant = self.get_variant_from_repo(repo)
        os_tree = os.path.join(rcm_pdc.get_compose_dir(self.compose), variant.paths.os_tree[repo['arch']])

        dir_blacklist = []
        file_blacklist = []
        if repo['service'] == "rhn":
            file_blacklist.extend(["boot.iso", ".discinfo"])
            dir_blacklist.extend(["Packages",])
        ti = productmd.treeinfo.TreeInfo()
        ti.load(os.path.join(rcm_pdc.get_compose_dir(self.compose), os_tree, ".treeinfo"))
        if not ti.stage2: # todo check this
            return None

        result = set()
        self.logger.debug("Walking %s to get kstree files" % os_tree)
        for root, dirs, files in os.walk(os_tree):
            relative_root = relative_path(os_tree, root)

            for d in dirs:
                if d in dir_blacklist:
                    self.logger.info("Skipping directory %s due dir_blacklist %s" % (d, str(dir_blacklist)))
                    dirs.remove(d)

            for f in files:
                if f in file_blacklist:
                    self.logger.info("Skipping file %s due file_blacklist %s" % (f, str(file_blacklist)))
                else:
                    result.add(os.path.join(relative_root, f))

        return result

    def link_ks_tree(self, repo, create_symlinks=False):
        """
        @param repo - rcm_pdc repo
        @param Packages - bool
        @param repodata - bool
        """
        target_dir = self.get_repo_staging_dir(repo)
        self.logger.info("Staging ks_tree data for %s into %s" % (repo_debug_str(repo), target_dir))
        ks_files = self.get_tree_files(repo)
        os_tree = os.path.join(rcm_pdc.get_compose_dir(self.compose), self.get_variant_from_repo(repo).paths.os_tree[repo['arch']])
        self.logger.debug("len(ks_files) == %d" % len(ks_files))
        self.logger.debug("os_tree=%s" % os_tree)
        for f in ks_files:
            src = os.path.normpath(os.path.join(os_tree, f))
            dst = os.path.normpath(os.path.join(target_dir, f))
            mkdirs(os.path.dirname(dst))

            if os.path.basename(f) == ".discinfo":
                if repo['service'] in (rcm_pdc.content_service.PULP, rcm_pdc.content_service.CDN):
                    dst = os.path.normpath(os.path.join(target_dir, "discinfo"))

            if os.path.basename(f) == ".treeinfo":
                if repo['service'] in (rcm_pdc.content_service.PULP, rcm_pdc.content_service.CDN):
                    dst = os.path.normpath(os.path.join(target_dir, "treeinfo"))

                if repo['service'] in (rcm_pdc.content_service.RHN,):
                    ti = modify_treeinfo(src)
                    self.logger.debug("%s -> %s" % (src, dst))
                    ti.dump(dst)
                    continue

            self.logger.debug("%s -> %s" % (src, dst))
            if create_symlinks:
                symlink(src, dst)
            else:
                link(src, dst)

    def create_rhn_scripts_sh(self, target, repos):
        version = self.ci.release.version
        install = "%s_%s" % (self.ci.release.short.lower(), self.ci.release.major_version) # rhel_7 for example
        register_data = """#!/bin/sh

VERSION='%s'
INSTALL='%s'
EXISTS='--ks-exists'
FORCE='--force'
CLEAR='--clear' # --force doesn't always overwrite existing kickstarts, --clear should help

read -p 'RHN Server [qa]: ' SERVER
SERVER=${SERVER:=qa}

read -p 'RHN User [rhel-admin]: ' USERNAME
USERNAME=${USERNAME:=rhel-admin}

read -p "RHN Password for $USERNAME: " -s PASSWORD
echo

function error() {
  local code="${3:-1}"
  echo "Script failed"
  exit "${code}"
}
trap error ERR

set -x
set -e

""" % (version, install)
        data = """#!/bin/sh

VERSION='%s'
INSTALL='%s'
EXISTS='--ks-exists'
FORCE='--force'
CLEAR='--clear' # --force doesn't always overwrite existing kickstarts, --clear should help

read -p 'RHN Server [qa]: ' SERVER
SERVER=${SERVER:=qa}

read -p 'RHN User [rhel-admin]: ' USERNAME
USERNAME=${USERNAME:=rhel-admin}

read -p "RHN Password for $USERNAME: " -s PASSWORD
echo

function error() {
  local code="${3:-1}"
  echo "Script failed"
  exit "${code}"
}
trap error ERR

set -x
set -e

echo 'Uploading files to RHN...'
/mnt/redhat/scripts/rel-eng/utility/rhn/rhn-upload --server=$SERVER --user=$USERNAME --password=$PASSWORD --local-root=$(dirname $(readlink -f $0))/pub/rhn/kickstart --remote-root=rhn/kickstart $FORCE -v

""" % (version, install)

        mkdirs(target)
        script_path = os.path.join(target, self.rhn_upload_script_filename)
        open(script_path, "w").write(data) # write upload only script
        os.chmod(script_path, 0755)


        for repo in repos:
            data += "echo 'Registering kickstart to %s...'\n" % repo['name']
            register_data += "echo 'Registering kickstart to %s...'\n" % repo['name']
            data += "rhn-manage-ks-tree --server=$SERVER --user=rhel-admin --password=$PASSWORD --commit --create $EXISTS $CLEAR --channel=%s --install=$INSTALL --update=$VERSION --tree-type=rhn-managed -v\n" % repo['name']
            register_data += "rhn-manage-ks-tree --server=$SERVER --user=rhel-admin --password=$PASSWORD --commit --create $EXISTS $CLEAR --channel=%s --install=$INSTALL --update=$VERSION --tree-type=rhn-managed -v\n" % repo['name']

        script_path = os.path.join(target, self.rhn_register_script_filename)
        open(script_path, "w").write(register_data) # write register only script
        os.chmod(script_path, 0755)

        script_path = os.path.join(target, self.rhn_all_script_filename)
        open(script_path, "w").write(data) # write merged upload  + register script
        os.chmod(script_path, 0755)
