#!/usr/bin/env python

import os

import rcm_pdc
from .stage_images import StageImages

# As of now there is no implementation on pub side ... I only know that the directory is going to be called "DOCKER"

class StageContainers(StageImages):
        content_format = rcm_pdc.content_format.DOCKER
        def get_repo_staging_dir(self, repo):
            if self.content_format in (rcm_pdc.content_format.DOCKER, ):
                return os.path.join(super(StageContainers, self).get_repo_staging_dir(repo), "DOCKER")

        def handle_image(self, repo, image):
            staging_dir = self.get_service_staging_dir()

        def handle_repo(self, repo):
            images = self.get_related_images(repo, image_types=[rcm_pdc.content_format.DOCKER])
            if not images:
                return
            for image in images:
                self.handle_image(repo, image)
