#!/usr/bin/env python

import os
import csv

import productmd
from kobo.shortcuts import run

import rcm_pdc
from .stage_base import link, mkdirs, symlink
from .stage_images import StageImages, PubMapfile

def sha256sum(path):
    ret, out = run("sha256sum %s" % path)
    return out.split()[0]


def md5sum(path):
    ret, out = run("md5sum %s" % path)
    return out.split()[0]


class StageQCOW(StageImages):
    content_format = rcm_pdc.content_format.QCOW
    pub_mapfile_filename = "pub-mapfile.json"
    pulp_iso_reldir = "ISOS" # Used for qcow as well

    def do_stage(self):
        self.checksums = {'sha256': {}, 'md5': {}}
        self.pub_mapfiles = {}

        # all isos ... there is some action required so better to keep list of all first
        for repo in self.repos:
            self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
            self.handle_repo(repo)

        if self.pub_mapfiles:
            self.write_pub_mapfiles()


    def write_pub_mapfiles(self):
        # Handle pub-mapfile (pulp-only, legacy cdn doesn't process it)
        self.logger.info("Writing PUB mapfiles")
        for filename, pub_mapfile in self.pub_mapfiles.iteritems():
            if pub_mapfile.isEmpty():
                self.logger.debug("%s: skipped writing of %s as it would be empty" % (self.content_format, filename))
                continue
            # pub-mapfile per repo-family ..self.
            self.logger.info("%s: writing pub-mapfile into '%s'" % (self.content_format, filename))
            # Load content of existing pub-mapfile if exists and enabled
            if self.stage_options.get("merge_pub_mapfiles"):
                if os.path.isfile(filename):
                    self.logger.info("%s: loading and merging with existing pub-mapfile" % self.content_format)
                    pub_mapfile.load(filename)
            pub_mapfile.write(filename)

    def get_label_str(self, include_label_version_for=["snapshot"]):
        """
        @param include_label_version_for=["snapshot,"] (checked against milestone.lower())
        returns label consumable by UnifiedDownloads/RHN (e.g. Beta, Snapshot 3 ...)
        """
        if not self.compose_label or self.ci.compose.type != "production":
            return "%s%s.%s" % (self.ci.compose.date, self.ci.compose.type_suffix, self.ci.compose.respin)
        elif self.compose_label.startswith("RC") or self.compose_label.startswith("GA"):
            return ""

        milestone, version = self.compose_label.split("-")
        if milestone.lower() in include_label_version_for:
            return "%s %s" % (milestone, productmd.common.get_major_version(version))
        else:
            return "%s" % (milestone)

    def get_image_description(self, repo, image):
        """
        @param repo
        @param image
        returns description used in unified downloads e.g. 'RHEL 6.7 Binary DVD 2'
        TODO: fix image.volume_id and use that instead
        """
        result = None
        content_category_string = repo['content_category'].title()
        image_type_string = image.type.upper()

        if image.type == "qcow2":
            content_category_string = "KVM"
            image_type_string = "Guest Image"

        if repo['service'] in (rcm_pdc.content_service.PULP, ):
            product_string = ""

            # TODO reduce this! $layered_product for $base.product  $base.product.version? in case that layered
            if self.ci.release.is_layered:
                if self.ci.release.name == "Supplementary":
                    # we have to use product.version (6.7) instead of base_product.version (6) behind the base_product.short
                    product_string = "%s %s %s" % (self.ci.base_product.short, self.ci.release.version, self.ci.release.name)
                else:
                    if repo['variant_uid'] == self.ci.release.short:
                        # We don't want Red Hat Satellite Satellite ...
                        product_string = "%s %s" % (self.ci.release.name, self.ci.release.version)
                    else:
                        product_string = "%s %s %s" % (self.ci.release.name, self.ci.variants[repo['variant_uid']].name, self.ci.release.version)
            else:
                product_string = "%s %s" % (self.ci.release.name, self.ci.release.version)

            result = "%s" % product_string
            if self.get_label_str():
                result += " %s" % self.get_label_str()
            result += " %s %s" % (content_category_string, image_type_string)

        return result

    def get_ud_version(self, repo, image):
        """
        @param repo
        @param image
        returns version used in unified downloads e.g. '6.1 Beta'
        """
        ud_version = str(self.ci.release.version)
        if repo['repo_family'] in (rcm_pdc.repo_family.BETA, rcm_pdc.repo_family.HTB):
            ud_version += " Beta"
        return ud_version


    def get_image_arch(self, image):
        if image.arch == "src":
            return "source"
        return image.arch

    def get_image_label_str(self, include_milestone_ver=True):
        # TODO: please merge  with get_label_str
        result = ""
        if self.compose_label and (self.compose_label.startswith("RC") or self.compose_label.startswith("GA")):
            return result
        elif self.compose_label:
            milestone, ver = self.compose_label.split("-")
            result = milestone
            if include_milestone_ver:
                result += "-%s" % productmd.common.get_major_version(ver)
        else:
            result = "%s%s.%s" % (self.ci.compose.date, self.ci.compose.type_suffix, self.ci.compose.respin)

        return result

    def get_image_type_label(self, repo, image):
        image_type_string = None

        if image.type == "qcow2":
            image_type_string = "kvm"

        return image_type_string

    def get_image_name(self, image, repo):
        image_arch = self.get_image_arch(image)
        image_type = image.type
        if image.type == rcm_pdc.content_format.QCOW:
            image_type = "kvm" # we don't want name*qcow2.qcow2
        variant = repo['variant_uid'].lower()
        label = self.get_image_label_str().lower()
        name = self.ci.release.short.lower()
        if variant.lower() != self.ci.release.short.lower():
            # satellite-satellite-6.0 -> satellite-6.0
            name += "-%s" % variant
        name += "-%s" % self.ci.release.version
        if self.ci.release.is_layered:
            name += "-%s-%s" % (self.ci.base_product.short.lower(), self.ci.base_product.major_version)
        if label:
            name += "-%s" % label
        name += "-%s-%s" % (image_arch, image_type)
        name += ".%s" % image.format
        return name

    def handle_image(self, repo, image, create_symlinks=False):
        self.logger.info("handling %s" % os.path.basename(image.path))
        repo_staging_dir = self.get_repo_staging_dir(repo)
        full_path = os.path.join(self.compose_dir, image.path)
        self.logger.debug("%s -> %s" % (full_path, repo_staging_dir))
        image_filename = self.get_image_name(image, repo)
        target = os.path.join(repo_staging_dir, image_filename)

        if repo['service'] in (rcm_pdc.content_service.PULP,):
            # todo: define "md5sum" somwhere else
            target = os.path.join(repo_staging_dir, self.pulp_iso_reldir, image_filename)

        mkdirs(repo_staging_dir)
        if create_symlinks:
            symlink(full_path, target)
        else:
            link(full_path, target)

        # todo: sync input don't mix dict with args
        if repo['service'] in (rcm_pdc.content_service.PULP,):
            mapfile_path = os.path.join(self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow']), self.pub_mapfile_filename)
            self.pub_mapfiles.setdefault(mapfile_path, PubMapfile())

            self.pub_mapfiles[mapfile_path].addEntry({
                'relative_path': self.get_image_relative_path(repo, target),
                'filename': image_filename,
                'sha256sum': image.checksums['sha256'],
                'version': self.get_ud_version(repo, image),
                'attributes': {
                    'description': self.get_image_description(repo, image),
                },
            })


    def get_repo_staging_dir(self, repo):
        # get the staging dir which leads to staging/$service-$family/$repo

        return super(StageQCOW, self).get_repo_staging_dir(repo)

    def handle_repo(self, repo):
        images = self.get_related_images(repo, image_types=["qcow2",])
        if not images:
            return
        for image in images:
            self.handle_image(repo, image)
