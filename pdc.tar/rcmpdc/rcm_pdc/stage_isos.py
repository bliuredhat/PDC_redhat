#!/usr/bin/env python

import os
import csv
import productmd
from kobo.shortcuts import run

import rcm_pdc
from .stage_base import link, mkdirs, symlink
from .stage_images import StageImages, PubMapfile

def sha256sum(path):
    ret, out = run("sha256sum %s" % path)
    return out.split()[0]


def md5sum(path):
    ret, out = run("md5sum %s" % path)
    return out.split()[0]

class RHNMapfile(object):
    MAPFILE_HEADER = ["parse", "name", "file_size", "md5sum", "path", "download_type", "ordering", "category", "channel", "channel_family", "release_notes_url"]

    def __init__(self):
        self._content = []

    def read(self, path):
        self._content = []
        reader = csv.reader(open(path, "r"))
        for row in reader:
            if row[0] != "1":
                # skip header and disabled rows
                continue
            data = dict(zip(self.MAPFILE_HEADER, row))
            self._content.append(data)

    def write(self, path, records_per_file=3):
        writer = csv.writer(open(path, "w"), lineterminator="\n", quoting=csv.QUOTE_ALL)
        writer.writerow(self.MAPFILE_HEADER)
        for data in self._content:
            row = [data[i] for i in self.MAPFILE_HEADER]
            writer.writerow(row)

        c = 0
        for data in self._content:
            if c % records_per_file == 0:
                writer = csv.writer(open(path + "-split.%d" % (c // records_per_file), "w"), lineterminator="\n", quoting=csv.QUOTE_ALL)
                writer.writerow(self.MAPFILE_HEADER)

            row = [data[i] for i in self.MAPFILE_HEADER]
            writer.writerow(row)
            c += 1

    def addEntry(self, name, file_size, md5sum, path, download_type, ordering, category, channel, channel_family=None, release_notes_url=None):
        channel_family = channel_family or ""
        release_notes_url = release_notes_url or ""
        data = ["1", name, file_size, md5sum, path, download_type, ordering, category, channel, channel_family, release_notes_url]
        self._content.append(dict(zip(self.MAPFILE_HEADER, data)))

    def isEmpty(self):
        return not bool(self._content)


class StageISOS(StageImages):
    MAX_RHN_CATEGORY_LEN=128

    content_format = rcm_pdc.content_format.ISO
    pub_mapfile_filename = "pub-mapfile.json"
    rhn_mapfile_filename = "mapfile"
    rhn_iso_reldir = "md5sum"
    pulp_iso_reldir = "ISOS"
    rhn_upload_script_filename = "upload-isos.sh"
    rhn_upload_mapfile_script_filename = "upload-mapfile.sh"

    def do_stage(self):
        self.checksums = {'sha256': {}, 'md5': {}}
        self.pub_mapfiles = {}
        self.rhn_mapfiles = {}

        # all isos ... there is some action required so better to keep list of all first
        for repo in self.repos:
            self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'], repo['content_format'], self.get_repo_name(repo), repo['arch']))
            self.handle_repo(repo)

        if self.pub_mapfiles:
            self.write_pub_mapfiles()
        if self.rhn_mapfiles:
            self.write_rhn_mapfiles()

        for filename in self.rhn_mapfiles.keys():
            self.write_rhn_upload_isos_sh(os.path.dirname(filename))
            self.write_rhn_upload_mapfile_sh(os.path.dirname(filename))

    def get_rhn_product(self):
        result = "%s-%s" % (self.ci.release.short.lower(), self.ci.release.version)
        if self.ci.release.is_layered:
            result += "-%s-%s" % (self.ci.base_product.short.lower(), self.ci.base_product.major_version)
        return result

    def write_rhn_upload_isos_sh(self, staging_dir):
        script_path = os.path.join(staging_dir, self.rhn_upload_script_filename)
        self.logger.info("%s: writing %s" % (self.content_format, script_path))
        data = """#!/bin/sh

read -p 'RHN Server [qa]: ' SERVER
SERVER=${SERVER:=qa}

read -p 'RHN User [rhel-admin]: ' USERNAME
USERNAME=${USERNAME:=rhel-admin}

#read -p "RHN Password for $USERNAME: " -s PASSWORD
#echo

SCRIPT_DIR=$(dirname $(readlink -f $0))

function error() {
  local code="${3:-1}"
  echo "Script failed"
  exit "${code}"
}
trap error ERR

set -x
set -e

/mnt/redhat/scripts/rel-eng/utility/rhn/rhn-upload --log-directory=$SCRIPT_DIR/logs-$SERVER --local-root=$SCRIPT_DIR/md5sum --remote-root=rhn/isos/%s/md5sum --server=$SERVER --user=$USERNAME --verbose
""" % (self.get_rhn_upload_dir())
        mkdirs(staging_dir)
        script_path = os.path.join(staging_dir, self.rhn_upload_script_filename)
        open(script_path, "w").write(data)
        os.chmod(script_path, 0755)

    def write_rhn_upload_mapfile_sh(self, staging_dir):
        script_path = os.path.join(staging_dir, self.rhn_upload_mapfile_script_filename)
        self.logger.info("%s: writing %s" % (self.content_format, script_path))
        data = """#!/bin/sh

read -p 'RHN Server [qa]: ' SERVER
SERVER=${SERVER:=qa}

read -p 'RHN User [rhel-admin]: ' USERNAME
USERNAME=${USERNAME:=rhel-admin}

#read -p "RHN Password for $USERNAME: " -s PASSWORD
#echo

SCRIPT_DIR=$(dirname $(readlink -f $0))

function error() {
  local code="${3:-1}"
  echo "Script failed"
  exit "${code}"
}
trap error ERR

set -x
set -e
rhn-download-manager --verbose --server=$SERVER --user=$USERNAME  --upload mapfile --prefix rhn/isos/%s --commit

## BACKUP
# for mapfile in mapfile-split*; do
#    rhn-download-manager --verbose --server=$SERVER --user=$USERNAME  --upload $mapfile --prefix rhn/isos/%s --commit
# done
""" % (self.get_rhn_upload_dir(), self.get_rhn_upload_dir())

        mkdirs(staging_dir)
        script_path = os.path.join(staging_dir, self.rhn_upload_mapfile_script_filename)
        open(script_path, "w").write(data)
        os.chmod(script_path, 0755)

    def write_rhn_mapfiles(self):
        self.logger.info("Writing RHN mapfiles")
        for filename, rhn_mapfile in self.rhn_mapfiles.iteritems():
            if rhn_mapfile.isEmpty():
                self.logger.debug("%s: skipped writing of mapfile %s as it would be empty" % (self.content_format, filename))
                continue
            self.logger.info("%s: writing pub-mapfile into '%s'" % (self.content_format, filename))
            rhn_mapfile.write(filename)

    def write_pub_mapfiles(self):
        # Handle pub-mapfile (pulp-only, legacy cdn doesn't process it)
        self.logger.info("Writing PUB mapfiles")
        for filename, pub_mapfile in self.pub_mapfiles.iteritems():
            if pub_mapfile.isEmpty():
                self.logger.debug("%s: skipped writing of %s as it would be empty" % (self.content_format, filename))
                continue
            # pub-mapfile per repo-family ..self.
            self.logger.info("%s: writing pub-mapfile into '%s'" % (self.content_format, filename))
            # Load content of existing pub-mapfile if exists and enabled
            if self.stage_options.get("merge_pub_mapfiles"):
                if os.path.isfile(filename):
                    self.logger.info("%s: loading and merging with existing pub-mapfile" % self.content_format)
                    pub_mapfile.load(filename)
            pub_mapfile.write(filename)

    def get_rhn_upload_dir(self):
        dirname = self.get_rhn_product().lower()
        suffix = ""
        if self.compose_label and not (self.compose_label.startswith("RC") or self.compose_label.startswith("GA")):
            suffix = "-%s" % self.compose_label.lower().split("-")[0]
        return "%s%s" % (dirname, suffix)

    def get_label_str(self, include_label_version_for=["snapshot"]):
        """
        @param include_label_version_for=["snapshot,"] (checked against milestone.lower())
        returns label consumable by UnifiedDownloads/RHN (e.g. Beta, Snapshot 3 ...)
        """
        if not self.compose_label or self.ci.compose.type != "production":
            return "%s%s.%s" % (self.ci.compose.date, self.ci.compose.type_suffix, self.ci.compose.respin)
        elif self.compose_label.startswith("RC") or self.compose_label.startswith("GA"):
            return ""

        milestone, version = self.compose_label.split("-")
        if milestone.lower() in include_label_version_for:
            return "%s %s" % (milestone, productmd.common.get_major_version(version))
        else:
            return "%s" % (milestone)

    def get_image_description(self, repo, image):
        """
        @param repo
        @param image
        returns description used in unified downloads e.g. 'RHEL 6.7 Binary DVD 2'
        TODO: fix image.volume_id and use that instead
        """
        result = None
        content_category_string = repo['content_category'].title()
        image_type_string = image.type.upper()

        if image.type == "boot":
            image_type_string = "ISO"
            content_category_string = image.type.title()  # set boot should be BOOT DVD not BINARY BOOT
        if repo['service'] in (rcm_pdc.content_service.PULP, ):
            product_string = ""

            # TODO reduce this! $layered_product for $base.product  $base.product.version? in case that layered
            if self.ci.release.is_layered:
                if self.ci.release.name == "Supplementary":
                    # we have to use product.version (6.7) instead of base_product.version (6) behind the base_product.short
                    product_string = "%s %s %s" % (self.ci.base_product.short, self.ci.release.version, self.ci.release.name)
                else:
                    if repo['variant_uid'] == self.ci.release.short:
                        # We don't want Red Hat Satellite Satellite ...
                        product_string = "%s %s" % (self.ci.release.name, self.ci.release.version)
                    else:
                        product_string = "%s %s %s" % (self.ci.release.name, self.ci.variants[repo['variant_uid']].name, self.ci.release.version)
            else:
                product_string = "%s %s" % (self.ci.release.name, self.ci.release.version)

            result = "%s" % product_string
            if self.get_label_str():
                result += " %s" % self.get_label_str()
            result += " %s %s" % (content_category_string, image_type_string)
        elif repo['service'] in (rcm_pdc.content_service.RHN,):
            result = self.get_image_type_label(repo, image)

        if image.disc_count > 1:
            result += str(image.disc_number)

        return result

    def get_ud_version(self, repo, image):
        """
        @param repo
        @param image
        returns version used in unified downloads e.g. '6.1 Beta'
        """
        ud_version = str(self.ci.release.version)
        if repo['repo_family'] in (rcm_pdc.repo_family.BETA, rcm_pdc.repo_family.HTB):
            ud_version += " Beta"
        return ud_version

    def get_ordering(self, image):
        # Returning 1 as it was causes duplicated records in RHN
        assert image.format == "iso", "Unknown image format: %s" % image.format
        assert image.type in ("dvd", "boot"), "Unknown image type: %s" % image.type
        if image.type == "boot":
            return 1  # first in the row
        elif image.arch != "src":
            return image.disc_number + 1  # +1 because boot iso has already 1
        elif image.arch == "src":
            # +10 is a workaround to be abovenon-src images, since they have separate disc count.
            # I don't expect more than 10 arch specific images per channel
            # however it could happen with DUDs ...
            return image.disc_number + 10
        raise ValueError("Don't know how to hande: %s" % image.path)

    # TODO rewrite this one ... it's just copy & pate from old code
    def get_rhn_category_label(self, repo, include_label_version=True):
        result = "%s %s" % (self.ci.release.name, self.ci.release.version)
        if self.get_label_str():
            result += " %s" % self.get_label_str()

        result += " %s" % str(repo['variant_uid'])

        if self.ci.release.is_layered:
            result += " for %s %s" % (self.ci.base_product.name, self.ci.base_product.major_version)
        result += " (%s)" % repo['arch']
        if len(result) >= StageISOS.MAX_RHN_CATEGORY_LEN:
            raise ValueError("Maximum length of rhn category is %d. Got len('%s') == %d" % (StageISOS.MAX_RHN_CATEGORY_LEN, result, len(result)))
        return result

    def get_disc_number_str(self, image):
        if image.disc_number and not (image.disc_number == image.disc_count == 1):
            return str(int(image.disc_number))
        return ""

    def get_image_arch(self, image):
        if image.arch == "src":
            return "source"
        return image.arch

    def get_image_label_str(self, include_milestone_ver=True):
        # TODO: please merge  with get_label_str
        result = ""
        if self.compose_label and (self.compose_label.startswith("RC") or self.compose_label.startswith("GA")):
            return result
        elif self.compose_label:
            milestone, ver = self.compose_label.split("-")
            result = milestone
            if include_milestone_ver:
                result += "-%s" % productmd.common.get_major_version(ver)
        else:
            result = "%s%s.%s" % (self.ci.compose.date, self.ci.compose.type_suffix, self.ci.compose.respin)

        return result

    def get_image_type_label(self, repo, image):
        content_category_string = repo['content_category'].title()
        image_type_string = image.type.upper()

        if image.type == "boot":
            image_type_string = "DVD"
            content_category_string = image.type.title()  # set boot should be BOOT DVD not BINARY BOOT
        return "%s %s" % (content_category_string.upper(), image_type_string)

    def get_image_name(self, image, repo):
        image_arch = self.get_image_arch(image)
        disc_number = self.get_disc_number_str(image)
        variant = repo['variant_uid'].lower()
        label = self.get_image_label_str().lower()
        name = self.ci.release.short.lower()
        if variant.lower() != self.ci.release.short.lower():
            # Satellite-Satellite-6.0 -> Satellite-6.0
            name += "-%s" % variant
        name += "-%s" % self.ci.release.version
        if self.ci.release.is_layered:
            name += "-%s-%s" % (self.ci.base_product.short.lower(), self.ci.base_product.major_version)
        if label:
            name += "-%s" % label
        name += "-%s-%s%s" % (image_arch, image.type, disc_number)
        name += ".%s" % image.format
        return name

    def handle_image(self, repo, image, create_symlinks=False):
        self.logger.info("Handling %s" % os.path.basename(image.path))
        repo_staging_dir = self.get_repo_staging_dir(repo)
        full_path = os.path.join(self.compose_dir, image.path)
        self.logger.debug("%s -> %s" % (full_path, repo_staging_dir))
        image_filename = self.get_image_name(image, repo)
        target = os.path.join(repo_staging_dir, image_filename)
        if repo['service'] in (rcm_pdc.content_service.RHN,):
            # TODO: define "md5sum" somwhere else
            target = os.path.join(repo_staging_dir, self.rhn_iso_reldir, image.checksums['md5'], image_filename)
        elif repo['service'] in (rcm_pdc.content_service.PULP,):
            # TODO: define "md5sum" somwhere else
            target = os.path.join(repo_staging_dir, self.pulp_iso_reldir, image_filename)

        mkdirs(repo_staging_dir)
        if create_symlinks:
            symlink(full_path, target)
        else:
            link(full_path, target)

        # TODO: sync input don't mix dict with args
        if repo['service'] in (rcm_pdc.content_service.PULP,):
            mapfile_path = os.path.join(self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow']), self.pub_mapfile_filename)
            self.pub_mapfiles.setdefault(mapfile_path, PubMapfile())

            self.pub_mapfiles[mapfile_path].addEntry({
                'relative_path': self.get_image_relative_path(repo, target),
                'filename': image_filename,
                'sha256sum': image.checksums['sha256'],
                'version': self.get_ud_version(repo, image),
                'attributes': {
                    'description': self.get_image_description(repo, image),
                },
            })

        if repo['service'] in (rcm_pdc.content_service.RHN,):
            mapfile_path = os.path.join(self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow']), self.rhn_mapfile_filename)
            self.rhn_mapfiles.setdefault(mapfile_path, RHNMapfile())
            self.rhn_mapfiles[mapfile_path].addEntry(
                name=self.get_image_description(repo, image),
                file_size=image.size,
                md5sum=image.checksums['md5'],
                path=os.path.join(self.rhn_iso_reldir, image.checksums['md5'], image_filename),
                download_type=image.format,
                ordering=self.get_ordering(image),
                category=self.get_rhn_category_label(repo),
                channel=repo['name'],
                channel_family=None,
                release_notes_url=None
            )

    def get_repo_staging_dir(self, repo):
        # get the staging dir which leads to staging/$service-$family/$repo

        # push-staged doesn't work here :-)
        if repo['service'] in (rcm_pdc.content_service.RHN,):
            return self.get_service_staging_dir(repo['service'], repo['repo_family'], shadow=repo['shadow'])

        return super(StageISOS, self).get_repo_staging_dir(repo)

    def handle_repo(self, repo):
        images = self.get_related_images(repo, image_types=["boot", "dvd"])
        if not images:
            return
        for image in images:
            self.handle_image(repo, image)
