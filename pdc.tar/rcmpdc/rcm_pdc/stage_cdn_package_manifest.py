#!/usr/bin/env python

import os
try:
    import simplejson as json
except ImportError:
    import json

import rcm_pdc
from .repos import PulpRepo
from .stage_rpms import StageRPMS
from .stage_base import StageBase, mkdirs
from .engproxy_wrapper import *
from productmd.rpms import Rpms

class StageCDNPackageManifest(StageRPMS):
    """
    Inheritance is done so I can easily inherit prune_repo function
    """
    content_format = rcm_pdc.content_format.CDN_PACKAGE_MANIFEST
    cdn_manifest_filename = "PACKAGE_MANIFEST"

    def __init__(self, compose, pdc_proxy, logger, options=None):
        super(StageCDNPackageManifest, self).__init__(compose, pdc_proxy, logger, options)
        self.manifests = {}
        self.engproxy = EngProxyCSVWrapper(server=self.stage_options['eng_proxy_env'])
        self.rpm_manifest.load(rcm_pdc.get_rm_location(self.compose))
        self.old_rpm_manifest = Rpms() #  Populated in do_stage

    def get_related_content_format(self):
        return [rcm_pdc.content_format.RPM]

    def get_pid_template(self, repo, pid=None):
        """
        @param repo
        @param pid=None
        """
        if not pid:
            pid = repo['product_id']

        platform = self.ci.release.short
        platform_version = self.ci.release.version
        if self.ci.release.is_layered:
            platform = self.ci.base_product.short
            platform_version = self.ci.base_product.version

        result = {
            pid: {
                "Name": self.engproxy.get_product_name(repo),
                "Platform": platform,
                "Platform Version": platform_version,
                "Product ID": pid,
                "Product Version": self.ci.release.version,
                "Repo Paths": {}
            }
        }
        return result


    def get_cdn_reldir(self, repo, expand_yum_vars=True):
        """
        @param repo
        @param expand_yum_vars=True - qe is complaining about need for manual substitution
        """
        def substitute_yum_vars(reldir, pulp_repo):
            reldir = reldir.replace("$releasever", pulp_repo.releasever)
            reldir = reldir.replace("$basearch", pulp_repo.basearch)
            return reldir
        p_repo = PulpRepo(repo)
        content_set = self.engproxy.get_eng_proxy_content_set_record(repo)
        reldir = content_set["Download URL"]
        if expand_yum_vars:
            reldir = substitute_yum_vars(reldir, p_repo)
        return reldir

    def get_repo_record(self, repo):
        """
        @param repo
        """
        rpms = sorted(self.rpms_dict_to_list(self.get_related_rpms(repo, self.stage_options['prune'], self.rpm_manifest, data_glob=self.stage_options['data_glob'])))
        p_repo = PulpRepo(repo)
        result = {
            self.get_cdn_reldir(repo): {
                "Label": p_repo.repo_label,
                "RPMs": rpms,
                "basearch": p_repo.basearch,
                "releasever": p_repo.releasever,

            }
        }
        return result

    def handle_repo(self, repo):
        self.logger.info("Processing %s/%s/%s/%s/%s" % (repo['repo_family'], repo['service'],
                         repo['content_format'], self.get_repo_name(repo), repo['arch']))
        pid = repo['product_id']
        if not pid:
            return False
        staging_dir = self.get_service_staging_dir(service=rcm_pdc.content_service.PULP, repo_family=repo['repo_family'], shadow=repo['shadow'])
        manifest_filename = os.path.join(staging_dir, self.cdn_manifest_filename)
        self.manifests.setdefault(manifest_filename, {'cdn': {'products': {}}})
        self.manifests[manifest_filename]["cdn"]["products"].setdefault(pid, self.get_pid_template(repo)[pid])
        self.manifests[manifest_filename]["cdn"]["products"][pid]["Repo Paths"].update(self.get_repo_record(repo))
        return True

    def do_stage(self):
        # We need to be able to provide pruned manifest together with pruned rpms
        if self.stage_options['prune']: # e.g. 7.3 GA released compose for 7.4 Beta
                self.old_rpm_manifest = Rpms()
                self.old_rpm_manifest.load(rcm_pdc.get_rm_location(self.stage_options['prune_against']))

        for repo in self.repos:
            if repo['service'] != rcm_pdc.content_service.PULP:
                continue
            if not self.handle_repo(repo):
                self.logger.warning("Ignoring '%s' (%s):  no product id specified in PDC" % (repo["name"], repo["id"]))
        self.write_cdn_package_manifests()

    def write_cdn_package_manifests(self):
        for filename, manifest in self.manifests.iteritems():
            mkdirs(os.path.dirname(filename))
            self.logger.info("Writing %s into %s" % (self.content_format, filename))
            fd = open(filename, "w")
            fd.write(json.dumps(manifest, sort_keys=True, indent=4, separators=(',', ': ')))
            fd.close()
