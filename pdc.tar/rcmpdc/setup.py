#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
from glob import glob

__version__ = '0.47'

def find_scripts(paths):
    scripts = []
    for path in paths:
        for script in glob('%s/*' % path):
            scripts.append(script)
    return scripts

setup(
    name='rcm-pdc',
    description='RCM workflow utilities for PDC',
    install_requires=[
        'cdn-utils',
        'kobo',
        'koji',
        'pdc-client',
        'productmd',
        'python-krbV',
        'rcm-errata',

        #'pexpect',
        # Package doesn't support python 2.6 since 3.0. Use system
        # one instead:
        # $ ln -vs $(/usr/bin/python -c 'import pexpect, os.path; print pexpect.__file__') \
        #          $(/usr/bin/env python -c 'import distutils.sysconfig; print(distutils.sysconfig.get_python_lib())')

        #'yum',
        # $ ln -vs $(/usr/bin/python -c 'import yum, os.path; print os.path.dirname(yum.__file__)') \
        #          $(/usr/bin/env python -c 'import distutils.sysconfig; print(distutils.sysconfig.get_python_lib())')

        #'rpm',
        # $ ln -vs $(/usr/bin/python -c 'import rpm, os.path; print os.path.dirname(rpm.__file__)') \
        #          $(/usr/bin/env python -c 'import distutils.sysconfig; print(distutils.sysconfig.get_python_lib())')
    ],
    version=__version__,
    url='https://mojo.redhat.com/docs/DOC-1020255',
    author='Luboš Kocman',
    author_email='lkocman@redhat.com',
    license='GPL',
    packages=find_packages(),
    scripts=find_scripts([
        'bin',
        'contrib']
    ),
    dependency_links=[
        'git+https://pagure.io/forks/pbabinca/koji.git@setup_WIP#egg=koji-1.11.0',
        'git+http://git.app.eng.bos.redhat.com/git/cdn-utils.git#egg=cdn-utils-0.1',
        'git+http://git.app.eng.bos.redhat.com/git/rcm-errata.git#egg=rcm-errata-0.7',
    ]
)
